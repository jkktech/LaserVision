LaserVision 0.8.0 - registration-mark alignment for LightBurn + Thunder/Ruida
===========================================================================

UPDATING (from 0.7.4 on)
  Keep "Start LaserVision.bat" in the main LaserVision folder and point your desktop shortcut
  at it. Unzip each new version next to the others (it arrives as its own LaserVision-x.y.z
  folder). The launcher always starts the newest one, and every version shares the
  settings.json next to the launcher - calibration, layers and IP carry over automatically.
  Old version folders can be deleted any time.

USER MANUAL
  Press "? Help" (top right) or F1 in LaserVision: opens manual\manual.html in your browser.

SETUP (once)
  1. Unzip this folder to C:\LaserVision (replacing the older test scripts is fine).
  2. Open Command Prompt and run:   py -m pip install pymupdf numpy opencv-python
  3. Double-click "LaserVision (simulated laser).bat" to try it with no laser
     (it also simulates the camera, so you can practise calibrating and auto-measuring).
     Double-click "LaserVision.bat" to use the real laser (LightBurn can stay open).

USING IT
  1. Open cut PDF...      Marks are found automatically (small filled dots).
  2. Sheet on bed         Rotate/flip until the picture matches the sheet on the bed.
                          The app tells you if it doesn't fit the bed.
  3. Laser                No Connect step: the app connects on the first jog, move or measure,
                          and lets go of the laser after 60 s idle (Settings) so LightBurn can
                          use it. "Release" hands it to LightBurn straight away.
  4. Measure marks        Mark 1 is ringed in blue (click another mark to start there).
                          Jog the red dot onto the centre of the mark (arrow keys, small
                          steps near the end), then press Record (or Enter).
                          After mark 1, "Go to mark" drives to where the next mark should be.
     Doubled cut lines: if any cut lines run less than 0.5 mm apart (a doubled line or a
                          traced/outlined stroke), the app warns you and circles them in red.
                          They'd be cut twice - check the file with the customer.
  5. Check the Result box Rotation / scale / skew should be small; red lines are warnings.
  6. Layers               "Layer presets from" = your everyday .lbrn2 file (chosen once, remembered).
                          Each colour can also be "Don't cut - leave out" or "Don't cut - show on
                          T2 (reference)". Click a colour swatch to see its lines on the bed.
                          Its layers are copied in unchanged. For each cut-line colour in the
                          customer's PDF, pick which of your layers it goes on (remembered).
  7. Save                 Saves next to the cut PDF with the same name (sticker_cut.lbrn2,
                          or sticker_cut.svg). Asks before replacing an existing file.
     Send to LightBurn    Saves, releases the laser and opens the file in LightBurn. Check it
                          there and press Start in LightBurn (LaserVision never starts a job).
                          LightBurn 2.2+: Settings > Pair with LightBurn... once, and LightBurn
                          confirms each file opened.

CAMERA (new in 0.7)
  Camera picture settings (button "Picture…", Windows driver dialog):
      Camera Control tab: UNTICK Low Light Compensation (it limits you to ~5 fps),
      untick Exposure Auto and set it by hand (start at -6). Video Proc Amp: untick
      White Balance Auto. If the picture is too dark, add light - don't raise Gain.
  Settings: camera number, size (1920x1080), rotation (270 = turned left 90°).

  CALIBRATE (button "Calibrate…") - once, and again if the camera is bumped or moved:
  Step 1  Scale     Put any printed black dot under the camera near the red crosshair,
                    press Measure scale. The head moves up to 3 mm around it.
  Step 2  Offset    Tape card / masking tape under the head, set the panel's pulse power LOW.
                    5 times: "Go to next spot" -> press PULSE on the laser's panel -> "Find burn".
                    The app compares a before/after picture to find each burn, then
                    "Save offset". The burns should agree within ~0.02 mm.
                    If a burn isn't found, click it in the camera picture.
  Check any time:   burn a pulse on scrap, click the burn in the camera picture - the
                    crosshair should land right on it.

  CAMERA HEALTH (bumped camera / sagging mount)
  After every camera-measured job the app checks the camera by itself: are the dots the size
  they usually are (camera height), and does a 3 mm test move land where the calibration says
  (camera twisted/tilted)? The Result box shows "Camera health"; a problem gives a warning.
  It learns what's normal over the first job after each calibration.
  It can't see a camera that only SLID sideways - for that, the optional reference dot:
  Calibrate… Step 3: a small black dot that never moves (machine frame, not the honeycomb).
  "Check camera" then measures it in seconds and can correct the offset without burns.
  Tick "Check the camera automatically before every Auto-measure" to do it every job.

  MEASURING WITH THE CAMERA
  Jog until mark 1 (orange on the bed view) shows in the camera picture, then press
  "Auto-measure all". It finds each mark (searching around if needed), centres on it and
  measures it. Esc or Stop halts the head. The Result box lists each mark's size and
  steadiness - a ! means check that one. Clicking the camera picture moves that spot
  under the crosshair. The red-dot method (Record red dot here) still works.

  GLOSSY MATERIAL (new in 0.7.26)
  Glossy sheets (black acrylic...) mirror the laser head, and that reflection moves with the
  camera. Anything that stays put in the picture while the head moves is now ignored, and the
  search carries on. Light marks on dark gloss (a white dot) are found by their outline.
  Tip: camera LEDs down / lower exposure helps a lot on gloss.

  LAYER PRESETS RE-READ (0.7.24 / 0.7.25)
  Your layer presets .lbrn2 is read again when you load a cut file or press Start over
  (so after changing it in LightBurn, press Start over). The layer picked for each
  colour is kept.

  "NOW:" BAR (new in 0.7.23)
  The blue bar above the status line says what the machine is doing right now - moving to a
  spot, waiting for the camera to settle, taking picture 3/6, measuring the circle,
  confirming... - with a timer. It turns yellow if one step takes over 12 s: if nothing is
  happening, press Stop (Esc).

  BLACK ON BLACK / LIGHT MARKS (new in 0.7.22)
  If no dark or coloured mark of the right size is found, auto looks for the round OUTLINE of
  a mark of the size in the cut file - lighter or darker than the material: gloss black on
  matte black, white on black, embossed. Settings "Mark detection" = shape forces it.
  Put the camera over mark 1 as usual; the other marks are found from there.

  COLOURED / GLITTERY MATERIAL (new in 0.7.21)
  Settings "Mark detection": auto (default) / brightness / colour. On coloured material the
  app also looks at the ink's COLOUR, not just how dark it is, so a sparkly mark on a glitter
  or metallic sheet is still read cleanly. auto picks whichever view sees the mark steadier;
  set colour to force it if a mark on coloured material still reads off-centre.

  MOVE SPEED (new in 0.7.20)
  The laser normally moves at the speed of the last job it ran (slow after a thick cut).
  LaserVision now sets the speed itself before every move (Settings):
    Travel speed between marks   200 mm/s  - moves of 5 mm or more
    Precise move speed            30 mm/s  - moves under 5 mm (centring, jogs, calibration)
  0 = leave the laser's speed alone. If the laser refuses the speed command you get one
  warning and moves carry on at the old speed.

IN LIGHTBURN
  SVG:   File > Import. LightBurn may drop the import anywhere, so with the imported group
         still selected, set the 3x3 anchor to TOP-LEFT and type the XPos / YPos shown in
         LaserVision's Result box. That puts it exactly where it was measured.
  .lbrn2: File > Open (not Import).
  Then:  set "Start From" to Absolute Coords; click a reg-mark circle (anchor centre) and
         check it matches a "measured centre" in the Result box; Frame with the red dot
         before the first real cut.
  Reg marks: in .lbrn2 files they are always on tool layer T1 (circle + centre cross) -
         visible for reference, never sent to the laser. SVGs contain no reg marks.

FILES
  laservision.py   the app          job.py    PDF reading, orientation, maths, LightBurn file
  ruida.py         laser comms      camera.py  camera, mark finder, calibration maths
  settings.json is created on first run (holds your camera calibration)
