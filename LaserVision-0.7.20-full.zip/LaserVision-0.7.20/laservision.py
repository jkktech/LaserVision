"""
LaserVision - registration-mark alignment for LightBurn + Ruida (Thunder Laser).

Version 0.7: head camera finds and measures the marks (the red-dot method still works).

  1. Open the customer's cut PDF. Registration marks are found automatically.
  2. Rotate / flip until the picture matches how the sheet lies on the bed.
  3. Connect to the laser (close LightBurn first) and start the camera.
  4. Jog the camera over mark 1 (orange), then Auto-measure: the app finds every
     mark, centres the camera on it and measures it.
  5. Save the corrected LightBurn file (and optionally open it in LightBurn / cut).

Run:  py laservision.py            (or  py laservision.py --simulate  to try it with no laser)
"""

import json
import os
import queue
import socket
import sys
import threading
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

import numpy as np

import math
import time

import job as J
from ruida import LaserError, Ruida, SimulatedRuida

try:
    import cv2
    import camera as K
except ImportError:          # camera features need:  py -m pip install opencv-python
    cv2 = K = None

APP_DIR = os.path.dirname(os.path.abspath(__file__))
# The root launcher points this at ONE settings file shared by every version (calibration survives updates)
SETTINGS_FILE = os.environ.get("LASERVISION_SETTINGS") or os.path.join(APP_DIR, "settings.json")
DEFAULTS = {
    "ip": "", "magic": "0x88", "bed_w": 1300.0, "bed_h": 900.0,
    "step": 1.0, "pointer_dx": 0.0, "pointer_dy": 0.0, "lightburn_flip_y": False,
    "last_dir": "", "out_format": "lbrn2", "preset_file": "", "color_map": {},
    # camera
    "cam_index": 0, "cam_size": "1920x1080", "cam_format": "mjpg", "cam_rotate": 270,
    "cam_model": None, "cam_scale_ok": False, "cam_offset_ok": False, "cam_offset_note": "",
    "cam_offset_guess": [0.0, 43.2],       # camera centre relative to the beam, mm (+Y = toward front)
    "cam_search_mm": 60.0, "cam_settle": 0.35, "cam_view_turn": "auto",
    "cam_frames": 6, "cam_confirm_mm": 0.02, "cam_hold": 0.5,
    "approach_mm": 1.0, "nudge_x": 0.0, "nudge_y": 0.0,
    "travel_speed": 200.0, "precise_speed": 30.0,
}
VERSION = "0.7.20"
CAM_W = 330                 # width of the live camera picture on screen
EDGE_MARGIN = 2.0          # mm - never send the head closer than this to the bed edge
STEPS = [0.01, 0.05, 0.1, 0.5, 1, 5, 10, 50]

COL = {"bg": "#1e2226", "bed": "#2b3036", "grid": "#3a4048", "sheet": "#e8e4dc",
       "cut": "#d63384", "mark": "#111111", "first": "#f59f00", "done": "#2f9e44",
       "target": "#1c7ed6", "head": "#e03131", "text": "#ced4da", "cam": "#20c997"}


class Stopped(Exception):
    pass


def load_settings():
    s = dict(DEFAULTS)
    try:
        with open(SETTINGS_FILE, encoding="utf-8") as f:
            s.update(json.load(f))
    except (OSError, ValueError):
        pass
    return s


def save_settings(s):
    try:
        with open(SETTINGS_FILE, "w", encoding="utf-8") as f:
            json.dump(s, f, indent=2)
    except OSError:
        pass


# ------------------------------------------------------------ laser worker

class LaserWorker:
    """Runs laser commands one at a time on a background thread so the window never freezes."""

    def __init__(self):
        self.q = queue.Queue()
        self.results = queue.Queue()
        self.busy = False
        threading.Thread(target=self._run, daemon=True).start()

    def submit(self, fn, on_done=None, on_error=None):
        self.busy = True
        self.q.put((fn, on_done, on_error))

    def _run(self):
        while True:
            fn, ok, err = self.q.get()
            try:
                res = fn()
                self.results.put((ok, res, None))
            except Exception as e:          # report every failure to the UI
                self.results.put((err, None, e))
            finally:
                if self.q.empty():
                    self.busy = False


# ------------------------------------------------------------ the app

class App:
    def __init__(self, root, simulate=False):
        self.root = root
        self.s = load_settings()
        self.simulate = simulate
        self.laser = None
        self.worker = LaserWorker()
        self.head = None                 # (x, y) mm, last known
        self.job = None
        self.orient = J.Orientation()
        self.first_override = None       # mark index chosen by clicking
        self.measured = {}               # mark index -> (x, y) machine mm
        self.motion_ok = False           # user confirmed path is clear this session
        self.nominal_offset = None       # translation used before any mark is measured
        self.mark_info = {}              # mark index -> camera measurement details
        self.timing = {"move_s": 0.0, "move_mm": 0.0, "wait_s": 0.0, "t0": None}
        # camera
        self.sim_laser = SimulatedRuida() if simulate else None
        self.cam = None
        self.cam_size = None             # (w, h) of the rotated picture
        self.cam_last = -1
        self.cam_view = None             # (x0, y0, scale) of what is shown, for clicks
        self.live_dots = []
        self._det_busy = False
        self.photo = None
        self.stop_evt = threading.Event()
        self.auto = False
        self.calib = None                # calibration window
        if self.s.get("cam_model"):
            self.model = K.CamModel.from_dict(self.s["cam_model"]) if K else None
        else:
            self.model = K.CamModel(C=self.s["cam_offset_guess"]) if K else None
            self.s["cam_scale_ok"] = self.s["cam_offset_ok"] = False

        root.title(f"LaserVision {VERSION} - registration alignment" + ("  [SIMULATED LASER + CAMERA]" if simulate else ""))
        root.geometry("1640x900")
        root.minsize(1250, 720)
        self._build_ui()
        root.after(50, self._poll_worker)
        root.after(1000, self._poll_position)
        root.protocol("WM_DELETE_WINDOW", self.on_close)
        self.redraw()

    # ---------------------------------------------------------------- UI
    def _build_ui(self):
        style = ttk.Style()
        try:
            style.theme_use("vista" if sys.platform == "win32" else "clam")
        except tk.TclError:
            pass

        top = ttk.Frame(self.root, padding=(8, 6))
        top.pack(side="top", fill="x")
        ttk.Button(top, text="Open cut PDF…", command=self.open_pdf).pack(side="left")
        ttk.Separator(top, orient="vertical").pack(side="left", fill="y", padx=10)
        ttk.Label(top, text="Sheet on bed:").pack(side="left")
        for text, fn in (("⟳ 90°", lambda: self.reorient("cw")), ("⟲ 90°", lambda: self.reorient("ccw")),
                         ("Flip ↔", lambda: self.reorient("h")), ("Flip ↕", lambda: self.reorient("v"))):
            ttk.Button(top, text=text, width=8, command=fn).pack(side="left", padx=2)
        self.orient_lbl = ttk.Label(top, text="", width=44)
        self.orient_lbl.pack(side="left", padx=10)
        self.fit_lbl = ttk.Label(top, text="")
        self.fit_lbl.pack(side="left")
        ttk.Button(top, text="? Help", width=8, command=self.open_manual).pack(side="right")

        body = ttk.Frame(self.root)
        body.pack(fill="both", expand=True)
        side = ttk.Frame(body, padding=8, width=440)
        side.pack(side="right", fill="y")
        side.pack_propagate(False)
        self._build_camera(body)
        self.canvas = tk.Canvas(body, bg=COL["bg"], highlightthickness=0)
        self.canvas.pack(side="left", fill="both", expand=True)
        self.canvas.bind("<Configure>", lambda e: self.redraw())
        self.canvas.bind("<Button-1>", self.on_canvas_click)
        self.canvas.bind("<Double-Button-1>", self.on_canvas_double)

        # --- laser
        lf = ttk.LabelFrame(side, text="1. Laser", padding=6)
        lf.pack(fill="x")
        row = ttk.Frame(lf)
        row.pack(fill="x")
        ttk.Label(row, text="IP").pack(side="left")
        self.ip_var = tk.StringVar(value=self.s["ip"])
        ttk.Entry(row, textvariable=self.ip_var, width=15).pack(side="left", padx=4)
        self.conn_btn = ttk.Button(row, text="Connect", command=self.toggle_connect)
        self.conn_btn.pack(side="left")
        ttk.Button(row, text="Settings", command=self.open_settings).pack(side="right")
        self.pos_lbl = ttk.Label(lf, text="Not connected", font=("Consolas", 11))
        self.pos_lbl.pack(anchor="w", pady=(4, 0))

        # --- jog
        jf = ttk.LabelFrame(side, text="2. Jog  (arrow keys work too)", padding=6)
        jf.pack(fill="x", pady=6)
        sr = ttk.Frame(jf)
        sr.pack(fill="x")
        ttk.Label(sr, text="Step mm").pack(side="left")
        self.step_var = tk.StringVar(value=f"{float(self.s['step']):g}")
        for st in STEPS:
            ttk.Radiobutton(sr, text=f"{st:g}", value=f"{st:g}", variable=self.step_var).pack(side="left")
        sr2 = ttk.Frame(jf)
        sr2.pack(fill="x", pady=(2, 0))
        ttk.Label(sr2, text="Any step:").pack(side="left")
        ttk.Entry(sr2, textvariable=self.step_var, width=7).pack(side="left", padx=4)
        ttk.Label(sr2, text="mm     (Shift + arrow key = 0.01 mm)", foreground="#666").pack(side="left")
        pad = ttk.Frame(jf)
        pad.pack(pady=4)
        ttk.Button(pad, text="▲ Back", width=9, command=lambda: self.jog(0, -1)).grid(row=0, column=1)
        ttk.Button(pad, text="◀ Left", width=9, command=lambda: self.jog(-1, 0)).grid(row=1, column=0)
        ttk.Button(pad, text="Right ▶", width=9, command=lambda: self.jog(1, 0)).grid(row=1, column=2)
        ttk.Button(pad, text="▼ Front", width=9, command=lambda: self.jog(0, 1)).grid(row=2, column=1)
        gr = ttk.Frame(jf)
        gr.pack(fill="x")
        ttk.Label(gr, text="Go to X").pack(side="left")
        self.gx = tk.StringVar()
        self.gy = tk.StringVar()
        ttk.Entry(gr, textvariable=self.gx, width=8).pack(side="left", padx=2)
        ttk.Label(gr, text="Y").pack(side="left")
        ttk.Entry(gr, textvariable=self.gy, width=8).pack(side="left", padx=2)
        ttk.Button(gr, text="Go", width=4, command=self.goto_entered).pack(side="left", padx=2)

        # --- measure
        mf = ttk.LabelFrame(side, text="3. Measure marks", padding=6)
        mf.pack(fill="x")
        self.step_lbl = ttk.Label(mf, text="Open a cut PDF to begin.", wraplength=410, justify="left")
        self.step_lbl.pack(anchor="w")
        cr = ttk.Frame(mf)
        cr.pack(fill="x", pady=(4, 0))
        self.auto_btn = ttk.Button(cr, text="▶ Auto-measure all (camera)", command=self.auto_measure)
        self.auto_btn.pack(side="left")
        self.find_btn = ttk.Button(cr, text="Find this mark", command=lambda: self.camera_find(False))
        self.find_btn.pack(side="left", padx=4)
        self.stop_btn = ttk.Button(cr, text="■ Stop", command=self.stop_motion)
        self.stop_btn.pack(side="left")
        br = ttk.Frame(mf)
        br.pack(fill="x", pady=4)
        self.go_btn = ttk.Button(br, text="Go to mark", command=self.goto_next_mark)
        self.go_btn.pack(side="left")
        self.rec_btn = ttk.Button(br, text="Record red dot here", command=self.record_mark)
        self.rec_btn.pack(side="left", padx=4)
        br2 = ttk.Frame(mf)
        br2.pack(fill="x")
        ttk.Button(br2, text="Undo last", command=self.undo_mark).pack(side="left")
        ttk.Button(br2, text="Start over", command=self.reset_measure).pack(side="left", padx=4)
        ttk.Button(br2, text="Sheet to head", command=self.sheet_to_head).pack(side="left")

        # --- output (packed at the bottom so it never gets pushed off-screen)
        of = ttk.LabelFrame(side, text="4. Cut file for LightBurn", padding=6)
        of.pack(side="bottom", fill="x")

        # --- result
        rf = ttk.LabelFrame(side, text="Result", padding=6)
        rf.pack(fill="both", expand=True, pady=6)
        self.result = tk.Text(rf, height=8, wrap="word", font=("Consolas", 9), relief="flat")
        self.result.pack(fill="both", expand=True)
        self.result.tag_configure("warn", foreground="#c92a2a")
        self.result.tag_configure("ok", foreground="#2b8a3e")

        pr = ttk.Frame(of)
        pr.pack(fill="x")
        ttk.Label(pr, text="Layer presets from").pack(side="left")
        self.preset_var = tk.StringVar(value=self.s["preset_file"])
        ttk.Entry(pr, textvariable=self.preset_var, state="readonly").pack(side="left", padx=4, fill="x", expand=True)
        ttk.Button(pr, text="…", width=3, command=self.pick_presets).pack(side="left")
        self.map_frame = ttk.Frame(of)          # one row per cut-line colour: colour -> your layer
        self.map_frame.pack(fill="x", pady=(4, 2))
        self.layers, self.map_vars = [], {}
        fr = ttk.Frame(of)
        fr.pack(fill="x")
        self.fmt_var = tk.StringVar(value=self.s["out_format"])
        ttk.Radiobutton(fr, text="LightBurn file", value="lbrn2", variable=self.fmt_var,
                        command=self._refresh_buttons).pack(side="left")
        ttk.Radiobutton(fr, text="SVG (to import into a project)", value="svg", variable=self.fmt_var,
                        command=self._refresh_buttons).pack(side="left", padx=6)
        ttk.Label(of, text="Reg marks always go on tool layer T1 (shown, never cut).",
                  foreground="#555").pack(anchor="w")
        orow = ttk.Frame(of)
        orow.pack(fill="x", pady=(4, 0))
        self.save_btn = ttk.Button(orow, text="Save", command=lambda: self.export())
        self.save_btn.pack(side="left")
        self.send_btn = ttk.Button(orow, text="Save + open in LightBurn", command=lambda: self.export("open"))
        self.send_btn.pack(side="left", padx=4)
        self.cut_btn = ttk.Button(orow, text="Save + CUT", command=lambda: self.export("cut"))
        self.cut_btn.pack(side="left")
        self._load_presets(self.s["preset_file"], quiet=True)

        self.status = ttk.Label(self.root, text="", relief="sunken", anchor="w", padding=(6, 2))
        self.status.pack(side="bottom", fill="x")

        for key, d in (("<Left>", (-1, 0)), ("<Right>", (1, 0)), ("<Up>", (0, -1)), ("<Down>", (0, 1))):
            self.root.bind(key, lambda e, d=d: self._key_jog(e, *d))
            self.root.bind("<Shift-" + key[1:], lambda e, d=d: self._key_jog(e, *d, fine=True))
        self.root.bind("<Return>", lambda e: self._key_record(e))
        self.root.bind("<Escape>", lambda e: self.stop_motion())
        self.root.bind("<F1>", lambda e: self.open_manual())
        self._refresh_buttons()

    def open_manual(self):
        """The user manual (manual/manual.html in this version's folder) in the web browser."""
        import webbrowser
        from pathlib import Path
        page = Path(APP_DIR) / "manual" / "manual.html"
        if not page.exists():
            messagebox.showinfo("Help", f"The manual wasn't found:\n{page}")
            return
        webbrowser.open(page.as_uri())

    def say(self, msg):
        self.status.config(text=msg)

    # ---------------------------------------------------------------- job / orientation
    def open_pdf(self):
        path = filedialog.askopenfilename(title="Open the CUT file (PDF)",
                                          initialdir=self.s.get("last_dir") or None,
                                          filetypes=[("PDF files", "*.pdf"), ("All files", "*.*")])
        if not path:
            return
        try:
            jb = J.Job(path)
        except Exception as e:
            messagebox.showerror("Could not read PDF", str(e))
            return
        self.s["last_dir"] = os.path.dirname(path)
        self.job = jb
        self.orient = J.Orientation()
        # pick the first orientation that fits the bed
        for _ in range(2):
            _, w, h = self.orient.frame(jb)
            if w <= self.s["bed_w"] and h <= self.s["bed_h"]:
                break
            self.orient = self.orient.rotated_cw()
        self.reset_measure(quiet=True)
        self._rebuild_map()
        if self.simulate:
            self._simulate_sheet()
        msg = f"Loaded {jb.name}: {jb.page_w:.1f} x {jb.page_h:.1f} mm, {len(jb.cut)} cut paths, {len(jb.marks)} marks."
        self.say(msg)
        margin = J.orientation_margin(jb.mark_xy)
        lines = [msg]
        if margin is not None:
            if margin < 5:
                lines.append(f"! Mark layout is nearly symmetric (margin {margin:.1f} mm): set the orientation carefully.")
            else:
                lines.append(f"Mark layout is distinct in every orientation (margin {margin:.0f} mm).")
        lines += ["! " + n for n in jb.notes]
        self.show_result(lines)
        if jb.close_lines:
            self.redraw()
            spots = "\n".join(f"  •  X {c['x']:.0f}, Y {c['y']:.0f} mm on the sheet - {c['length']:.0f} mm of line, "
                               f"about {c['gap']:.2f} mm apart" for c in jb.close_lines[:5])
            more = f"\n  …and {len(jb.close_lines) - 5} more" if len(jb.close_lines) > 5 else ""
            messagebox.showwarning(
                "Doubled cut lines?",
                f"This cut file has cut lines less than {J.CLOSE_LINE_MM:g} mm apart in "
                f"{len(jb.close_lines)} place{'s' if len(jb.close_lines) != 1 else ''} (red circles on the bed view):"
                f"\n\n{spots}{more}\n\nThat is usually a doubled line or a traced/outlined stroke. "
                "It would be cut twice. Check the file with the customer before printing.")

    def _simulate_sheet(self):
        """Simulation only: lay the sheet on the virtual bed, slightly crooked, as the camera will see it."""
        A0, w, h = self.orient.frame(self.job)
        th = math.radians(0.6)
        ty = max(15.0, self.s["bed_h"] - h - 15)
        self.sim_truth = J.compose(np.array([[1.0008 * math.cos(th), -1.0004 * math.sin(th), 60.0],
                                             [1.0008 * math.sin(th), 1.0004 * math.cos(th), ty]]), A0)
        pts = J.apply(self.sim_truth, self.job.mark_xy)
        world = [(x, y, m.size) for (x, y), m in zip(pts, self.job.marks)]
        world += [(x + 14, y + 9, 3.0) for x, y in pts]          # small artwork dots nearby (must be ignored)
        self.sim_world = world
        if self.cam is not None:
            self.cam.dots = world

    def reorient(self, how):
        if not self.job:
            return
        if self.measured and not messagebox.askyesno("Change orientation",
                                                     "This clears the marks measured so far. Continue?"):
            return
        self.orient = {"cw": self.orient.rotated_cw, "ccw": self.orient.rotated_ccw,
                       "h": self.orient.flipped_h, "v": self.orient.flipped_v}[how]()
        self.reset_measure(quiet=True)

    def oriented(self):
        """(A0 design->oriented, w, h, oriented mark positions)."""
        A0, w, h = self.orient.frame(self.job)
        return A0, w, h, J.apply(A0, self.job.mark_xy)

    def order(self):
        _, _, h, om = self.oriented()
        if self.first_override is None:
            return J.measure_order(om, h)
        rest = [i for i in J.measure_order(om, h) if i != self.first_override]
        out, pts = [self.first_override], om
        while rest:
            last = pts[out[-1]]
            nxt = min(rest, key=lambda i: np.hypot(*(pts[i] - last)))
            out.append(nxt)
            rest.remove(nxt)
        return out

    def placement(self):
        """Affine oriented->machine from the marks measured so far (or a nominal guess)."""
        _, w, h, om = self.oriented()
        if self.measured:
            idx = list(self.measured)
            return J.best_fit(om[idx], np.array([self.measured[i] for i in idx]))
        if self.nominal_offset is None:
            # nominal: sheet against the front-left of the bed
            self.nominal_offset = (10.0, self.s["bed_h"] - 10.0 - h)
        ox, oy = self.nominal_offset
        return np.array([[1, 0, ox], [0, 1, oy]], dtype=float)

    def sheet_to_head(self):
        """Move the on-screen sheet so the first mark sits under the head (before measuring)."""
        if not self.job or self.head is None:
            self.say("Connect to the laser first.")
            return
        if self.measured:
            self.say("Already measuring - use Start over first.")
            return
        _, _, _, om = self.oriented()
        first = self.order()[0]
        if self.cam is not None and self.model is not None:
            mx, my = self.model.to_machine(self.head, self.model.p0)      # under the camera crosshair
        else:
            mx, my = self._beam_from_head(*self.head)
        self.nominal_offset = (mx - om[first][0], my - om[first][1])
        self.redraw()

    # ---------------------------------------------------------------- drawing
    def _xf(self):
        cw, ch = self.canvas.winfo_width(), self.canvas.winfo_height()
        pad = 30
        s = max(0.05, min((cw - 2 * pad) / self.s["bed_w"], (ch - 2 * pad) / self.s["bed_h"]))
        ox = (cw - s * self.s["bed_w"]) / 2
        oy = (ch - s * self.s["bed_h"]) / 2
        return s, ox, oy

    def to_screen(self, pts):
        s, ox, oy = self._xf()
        pts = np.asarray(pts, float)
        return np.column_stack([ox + pts[:, 0] * s, oy + pts[:, 1] * s])

    def redraw(self):
        c = self.canvas
        c.delete("all")
        bw, bh = self.s["bed_w"], self.s["bed_h"]
        s, ox, oy = self._xf()
        c.create_rectangle(ox, oy, ox + bw * s, oy + bh * s, fill=COL["bed"], outline="#59616b")
        for gx in range(100, int(bw), 100):
            c.create_line(ox + gx * s, oy, ox + gx * s, oy + bh * s, fill=COL["grid"])
        for gy in range(100, int(bh), 100):
            c.create_line(ox, oy + gy * s, ox + bw * s, oy + gy * s, fill=COL["grid"])
        c.create_text(ox + 4, oy - 4, text="BACK  (0,0)", anchor="sw", fill=COL["text"], font=("Segoe UI", 9))
        c.create_text(ox + bw * s / 2, oy + bh * s + 4, text="FRONT  (you stand here)", anchor="n",
                      fill=COL["text"], font=("Segoe UI", 9))
        c.create_text(ox + bw * s, oy + bh * s + 4, text="double-click the bed to move there", anchor="ne",
                      fill="#8a939c", font=("Segoe UI", 8))
        c.create_text(ox + bw * s, oy - 4, text=f"{bw:g} x {bh:g} mm", anchor="se", fill=COL["text"],
                      font=("Segoe UI", 9))

        if self.job:
            A0, w, h, om = self.oriented()
            P = self.placement()
            full = J.compose(P, A0)
            sheet = J.apply(P, [[0, 0], [w, 0], [w, h], [0, h], [0, 0]])
            c.create_polygon(*self.to_screen(sheet).ravel(), fill=COL["sheet"], outline="#adb5bd")
            step = max(1, int(0.6 / max(s, 1e-6)))       # skip points closer than ~0.6 px
            hl = getattr(self, "highlight_color", None)
            for poly, pc in zip(self.job.cut, self.job.cut_colors):
                sp = self.to_screen(J.apply(full, poly[::step] if len(poly) > 3 * step else poly))
                if len(sp) < 2:
                    continue
                choice = self._color_choice(pc)
                if pc == hl:
                    c.create_line(*sp.ravel(), fill="#ff7a00", width=3)
                elif choice == "skip":
                    c.create_line(*sp.ravel(), fill="#9aa3ad", width=1, dash=(2, 3))
                elif choice == "ref":
                    c.create_line(*sp.ravel(), fill="#4dabf7", width=1, dash=(5, 3))
                else:
                    c.create_line(*sp.ravel(), fill=COL["cut"], width=1)
            for cl in getattr(self.job, "close_lines", []):      # doubled / too-close cut lines
                (x, y), = self.to_screen(J.apply(full, [[cl["x"], cl["y"]]]))
                c.create_oval(x - 11, y - 11, x + 11, y + 11, outline="#e03131", width=3)
            order = self.order()
            k = len(self.measured)
            nxt = order[k] if k < len(order) else None
            mpos = J.apply(P, om)
            for n, i in enumerate(order):
                (x, y), = self.to_screen(mpos[[i]])
                r = max(3, self.job.marks[i].size / 2 * s)
                color = COL["done"] if i in self.measured else COL["first"] if n == 0 else COL["mark"]
                c.create_oval(x - r, y - r, x + r, y + r, fill=color, outline="white" if i == nxt else color,
                              width=2 if i == nxt else 1, tags=("mark", f"m{i}"))
                c.create_text(x + r + 4, y - r - 2, text=str(n + 1), anchor="sw", fill="#000000",
                              font=("Segoe UI", 11, "bold"))
                if i == nxt:
                    R = r + 10
                    c.create_oval(x - R, y - R, x + R, y + R, outline=COL["target"], width=2, dash=(4, 3))
            for i, (mx, my) in self.measured.items():
                (x, y), = self.to_screen([[mx, my]])
                c.create_line(x - 8, y, x + 8, y, fill="white")
                c.create_line(x, y - 8, x, y + 8, fill="white")
            # fit / orientation labels
            fits = w <= bw and h <= bh
            self.orient_lbl.config(text=f"{self.orient.describe()}   ({w:.0f} x {h:.0f} mm)")
            self.fit_lbl.config(text="fits the bed" if fits else "DOES NOT FIT the bed - rotate it",
                                foreground="#2b8a3e" if fits else "#c92a2a")
            n_tot, n_done = len(order), len(self.measured)
            if n_done < n_tot:
                if self.cam is not None and self.head:
                    txt = (f"Mark {n_done + 1} of {n_tot} (ringed in blue). " +
                           ("Jog until it shows in the camera picture, then Auto-measure. "
                            "Click a mark to start somewhere else." if n_done == 0 else
                            "Auto-measure carries on, or Find this mark."))
                else:
                    verb = "Jog the red dot onto the centre of" if self.head else "Connect, then go to"
                    txt = (f"Mark {n_done + 1} of {n_tot} (ringed in blue). {verb} it, then Record. "
                           + ("Click a mark to start somewhere else." if n_done == 0 else ""))
                self.step_lbl.config(text=txt)
            else:
                self.step_lbl.config(text=f"All {n_tot} marks measured. Check the result, then save the cut file.")
        else:
            self.orient_lbl.config(text="")
            self.fit_lbl.config(text="")

        if self.head:
            (x, y), = self.to_screen([self.head])
            c.create_line(x - 14, y, x + 14, y, fill=COL["head"], width=2)
            c.create_line(x, y - 14, x, y + 14, fill=COL["head"], width=2)
            c.create_oval(x - 5, y - 5, x + 5, y + 5, outline=COL["head"], width=2)
        self._refresh_buttons()

    def on_canvas_double(self, e):
        """Double-click on the bed view: move there. With a calibrated camera the camera picture is
        centred on that spot; otherwise the laser head (red dot) goes there."""
        if not self.laser or self.head is None:
            self.say("Connect to the laser first, then double-click the bed to move there.")
            return
        s, ox, oy = self._xf()
        x, y = (e.x - ox) / s, (e.y - oy) / s
        if not (0 <= x <= self.s["bed_w"] and 0 <= y <= self.s["bed_h"]):
            return
        if self.cam is not None and self.s.get("cam_scale_ok") and self.s.get("cam_offset_ok"):
            hx, hy = self.model.head_to_view((x, y))
            label = f"Camera is looking at X {x:.1f}, Y {y:.1f}."
        else:
            hx, hy = x - float(self.s["pointer_dx"]), y - float(self.s["pointer_dy"])
            label = f"Head moved to X {x:.1f}, Y {y:.1f}."
        self.goto(hx, hy, label)

    def on_canvas_click(self, e):
        if not self.job or self.measured:
            return
        for item in self.canvas.find_overlapping(e.x - 6, e.y - 6, e.x + 6, e.y + 6):
            for t in self.canvas.gettags(item):
                if t.startswith("m") and t[1:].isdigit():
                    self.first_override = int(t[1:])
                    self.say(f"Measuring will start at that mark.")
                    self.redraw()
                    return

    def show_result(self, lines):
        self.result.delete("1.0", "end")
        for ln in lines:
            tag = "warn" if ln.startswith("!") else "ok" if ln.startswith("✓") else None
            self.result.insert("end", ln + "\n", tag)

    def _refresh_buttons(self):
        conn = self.laser is not None
        has_job = self.job is not None
        done = has_job and len(self.measured) == len(self.job.marks) and len(self.job.marks) >= 3
        lb = getattr(self, "fmt_var", None) is not None and self.fmt_var.get() == "lbrn2"
        cam = conn and self.cam is not None and bool(self.s.get("cam_scale_ok"))
        for b, on in ((self.go_btn, conn and has_job and not done), (self.rec_btn, conn and has_job and not done),
                      (self.auto_btn, cam and has_job and not done and not self.auto),
                      (self.find_btn, cam and has_job and not done and not self.auto),
                      (self.stop_btn, conn),
                      (self.check_btn, cam and bool(self.s.get("cam_ref"))),
                      (self.save_btn, done), (self.send_btn, done and lb),
                      (self.cut_btn, done and lb and bool(getattr(self, "layers", None)))):
            b.state(["!disabled"] if on else ["disabled"])

    # ---------------------------------------------------------------- laser
    def toggle_connect(self):
        if self.laser:
            self.disconnect()
            return
        self.s["ip"] = self.ip_var.get().strip()
        if not self.s["ip"] and not self.simulate:
            messagebox.showinfo("Connect", "Type the laser's IP address in the IP box first.\n"
                                           "It's the same address LightBurn uses (LightBurn > Devices).")
            return

        def work():
            if self.simulate:
                las = self.sim_laser
            else:
                las = Ruida(self.s["ip"], int(str(self.s["magic"]), 0))
            try:
                cid = las.card_id()
                bw, bh = las.bed_size_um()
                pos = las.position_um()
            except Exception:
                las.close()
                raise
            return las, cid, bw, bh, pos

        def done(res):
            las, cid, bw, bh, pos = res
            self.laser = las
            self._apply_speeds()
            if 100_000 < bw < 3_000_000 and 100_000 < bh < 3_000_000:
                self.s["bed_w"], self.s["bed_h"] = bw / 1000, bh / 1000
            self.head = (pos[0] / 1000, pos[1] / 1000)
            self.conn_btn.config(text="Disconnect")
            self.say(f"Connected (card 0x{cid:04X}, bed {bw/1000:g} x {bh/1000:g} mm).")
            self._show_pos()
            self.redraw()

        self.say("Connecting…")
        self.worker.submit(work, done, self._laser_error)

    def _apply_speeds(self):
        """Moves set their own speed, so they don't crawl at the speed of the last (thick) cut job."""
        if self.laser is None:
            return
        self.laser.travel_speed = max(0.0, float(self.s.get("travel_speed", 0) or 0))
        self.laser.precise_speed = max(0.0, float(self.s.get("precise_speed", 0) or 0))
        self.laser.speed_error = None
        self._speed_warned = False

    def disconnect(self):
        if self.laser:
            self.laser.close()
        self.laser = None
        self.head = None
        self.conn_btn.config(text="Connect")
        self.pos_lbl.config(text="Not connected")
        self.redraw()

    def _laser_error(self, e):
        messagebox.showerror("Laser", str(e))
        self.say(f"Laser problem: {e}")
        if not isinstance(e, LaserError) and self.laser:
            self.disconnect()

    def _show_pos(self):
        if self.head:
            self.pos_lbl.config(text=f"Head  X {self.head[0]:9.3f}   Y {self.head[1]:9.3f} mm")

    def _poll_position(self):
        if self.laser and not self.worker.busy:
            def work():
                return self.laser.position_um()

            def done(p):
                new = (p[0] / 1000, p[1] / 1000)
                if new != self.head:
                    self.head = new
                    self._show_pos()
                    self.redraw()
            self.worker.submit(work, done, lambda e: None)
        self.root.after(1000, self._poll_position)

    def _poll_worker(self):
        try:
            while True:
                cb, res, err = self.worker.results.get_nowait()
                if err is not None:
                    (cb or self._laser_error)(err)
                elif cb:
                    cb(res)
        except queue.Empty:
            pass
        self.root.after(50, self._poll_worker)

    def _in_bed(self, x, y):
        m = EDGE_MARGIN
        return m <= x <= self.s["bed_w"] - m and m <= y <= self.s["bed_h"] - m

    def _move(self, fn, label):
        def done(p):
            self.head = (p[0] / 1000, p[1] / 1000)
            self._show_pos()
            self.say(label)
            self.redraw()
            self._check_speed_error()
        self.worker.submit(fn, done, self._laser_error)

    def _step(self):
        try:
            v = float(str(self.step_var.get()).replace(",", "."))
        except (ValueError, tk.TclError):
            return None
        return v if 0.001 <= v <= 500 else None

    def jog(self, dx, dy, step=None):
        if not self.laser or self.head is None:
            self.say("Not connected.")
            return
        if self.worker.busy:
            return
        step = step if step is not None else self._step()
        if step is None:
            self.say("Type a step size in mm, for example 0.02.")
            return
        self.s["step"] = step
        tx, ty = self.head[0] + dx * step, self.head[1] + dy * step
        if not self._in_bed(tx, ty):
            self.say("Refused: that would leave the safe bed area.")
            return
        d = int(round(step * 1000))

        def work():
            if dx:
                self.laser.move_x_rel(dx * d)
            if dy:
                self.laser.move_y_rel(dy * d)
            return self.laser.wait_until_stopped()
        self._move(work, f"Jogged {step:g} mm.")

    def _key_jog(self, e, dx, dy, fine=False):
        if isinstance(e.widget, (tk.Entry, ttk.Entry, tk.Text)):
            return
        self.jog(dx, dy, step=0.01 if fine else None)

    def _key_record(self, e):
        if isinstance(e.widget, (tk.Entry, ttk.Entry, tk.Text)):
            return
        self.record_mark()

    def _confirm_motion(self, dist):
        if dist < 100 or self.motion_ok:
            return True
        ok = messagebox.askyesno("Head will move", f"The head will travel about {dist:.0f} mm.\n\n"
                                 "Lid closed and the path clear?\n(You won't be asked again this session.)")
        self.motion_ok = ok
        return ok

    def goto(self, x, y, label):
        if not self.laser or self.head is None:
            self.say("Not connected.")
            return
        if self.worker.busy:
            return
        if not self._in_bed(x, y):
            messagebox.showwarning("Out of range", f"({x:.1f}, {y:.1f}) is outside the safe bed area.")
            return
        if not self._confirm_motion(max(abs(x - self.head[0]), abs(y - self.head[1]))):
            return
        tx, ty = int(round(x * 1000)), int(round(y * 1000))
        self._move(lambda: self.laser.goto_um(tx, ty), label)

    def goto_entered(self):
        try:
            self.goto(float(self.gx.get()), float(self.gy.get()), "Arrived.")
        except ValueError:
            self.say("Enter X and Y in mm.")

    # ---------------------------------------------------------------- measuring
    def _beam_from_head(self, hx, hy):
        """Where the red dot is, given the head position (pointer offset from Settings)."""
        return hx + float(self.s["pointer_dx"]), hy + float(self.s["pointer_dy"])

    def goto_next_mark(self):
        if not self.job:
            return
        order = self.order()
        k = len(self.measured)
        if k >= len(order):
            return
        _, _, _, om = self.oriented()
        px, py = J.apply(self.placement(), om[[order[k]]])[0]
        hx, hy = px - float(self.s["pointer_dx"]), py - float(self.s["pointer_dy"])
        self.goto(hx, hy, f"At the predicted spot for mark {k + 1}. Jog the red dot onto its centre, then Record.")

    def record_mark(self):
        if not self.job or not self.laser or self.worker.busy:
            return
        order = self.order()
        k = len(self.measured)
        if k >= len(order):
            return

        def done(p):
            self.head = (p[0] / 1000, p[1] / 1000)
            self.measured[order[k]] = self._beam_from_head(*self.head)
            self.say(f"Recorded mark {k + 1} at X {self.measured[order[k]][0]:.3f}, Y {self.measured[order[k]][1]:.3f}.")
            self.update_result()
            self.redraw()
        self.worker.submit(lambda: self.laser.position_um(), done, self._laser_error)

    def undo_mark(self):
        if self.measured:
            last = self.order()[len(self.measured) - 1]
            self.measured.pop(last, None)
            self.mark_info.pop(last, None)
            self.update_result()
            self.redraw()

    def reset_measure(self, quiet=False):
        if not quiet and self.measured and not messagebox.askyesno("Start over", "Clear all measured marks?"):
            return
        self.measured = {}
        self.timing = {"move_s": 0.0, "move_mm": 0.0, "wait_s": 0.0, "t0": None}
        self.mark_info = {}
        self.health_lines = []
        self.ref_checked = False
        self.first_override = None
        self.nominal_offset = None
        if not quiet:
            self.show_result([])
        self.redraw()

    def final_transform(self):
        """design -> machine, only when every mark is measured."""
        if not self.job or len(self.measured) < len(self.job.marks) or len(self.job.marks) < 3:
            return None, None
        A0, _, _, om = self.oriented()
        idx = list(self.measured)
        src, dst = om[idx], np.array([self.measured[i] for i in idx])
        A = J.fit_affine(src, dst)
        info = J.describe_fit(A, src, dst)
        nx, ny = float(self.s.get("nudge_x", 0.0)), float(self.s.get("nudge_y", 0.0))
        A = A.copy()
        A[:, 2] += (nx, ny)          # your fine adjustment (Settings), applied to the whole cut
        return J.compose(A, A0), info

    def update_result(self):
        if not self.job:
            return
        n = len(self.measured)
        lines = [f"Measured {n} of {len(self.job.marks)} marks."] + list(getattr(self, "health_lines", []))
        order = self.order()
        size = self.job.marks[0].size
        for k, i in enumerate(order):
            inf = self.mark_info.get(i)
            if inf:
                flag = "!" if abs(inf["d_mm"] / size - 1) > 0.15 or inf["spread_mm"] > 0.03 else " "
                lines.append(f"{flag} #{k + 1}: dot {inf['d_mm']:.2f} mm, steady ±{inf['spread_mm']:.3f}, "
                             f"confirmed {inf.get('confirm_mm', 0):.3f} ({inf.get('readings', 1)} readings)")
        if n >= 2:
            _, _, _, om = self.oriented()
            idx = list(self.measured)
            A = J.best_fit(om[idx], np.array([self.measured[i] for i in idx]))
            info = J.describe_fit(A, om[idx], np.array([self.measured[i] for i in idx]))
            lines += [f"Rotation   {info['rotation_deg']:+.3f}°",
                      f"Scale X    {100 * (info['scale_x'] - 1):+.3f} %",
                      f"Scale Y    {100 * (info['scale_y'] - 1):+.3f} %"]
            if n >= 3:
                lines.append(f"Skew       {info['skew_deg']:+.3f}°")
            if n >= 4:
                lines.append(f"Mark agreement: worst {info['max_residual']:.3f} mm")
            lines += ["! " + w for w in info["warnings"]]
        full, info = self.final_transform()
        if full is not None:
            pts = np.vstack([J.apply(full, p) for p in self.job.cut])
            inside = (pts[:, 0].min() >= 0 and pts[:, 1].min() >= 0 and
                      pts[:, 0].max() <= self.s["bed_w"] and pts[:, 1].max() <= self.s["bed_h"])
            if not inside:
                lines.append("! Some cut lines fall outside the bed.")
            nx, ny = float(self.s.get("nudge_x", 0.0)), float(self.s.get("nudge_y", 0.0))
            if nx or ny:
                lines.append(f"  Cut nudge from Settings: X {nx:+.2f}  Y {ny:+.2f} mm")
            if not info["warnings"] and inside:
                lines.append("✓ Ready to save the cut file.")
        self.show_result(lines)

    # ---------------------------------------------------------------- output
    # presets: the layers saved in your everyday LightBurn file
    def pick_presets(self):
        p = filedialog.askopenfilename(title="Your LightBurn file with the layer presets you use",
                                       filetypes=[("LightBurn", "*.lbrn2"), ("All files", "*.*")])
        if p:
            self._load_presets(p)

    def _load_presets(self, path, quiet=False):
        self.layers = []
        if path:
            try:
                self.layers = J.read_layers(path)
            except Exception as e:
                if not quiet:
                    messagebox.showerror("Layer presets", f"Couldn't read layers from that file:\n{e}")
                path = ""
        self.preset_var.set(path)
        self.s["preset_file"] = path
        if path and not quiet:
            save_settings(self.s)
            self.say(f"Read {len(self.layers)} layers from {os.path.basename(path)}.")
        self._rebuild_map()

    # choices besides a real layer: leave the lines out, or keep them visible on tool layer T2
    SKIP_LABEL = "✕  Don't cut - leave out"
    REF_LABEL = "◌  Don't cut - show on T2 (reference)"
    NO_PRESET_LABEL = "00  (no presets file - set in LightBurn)"
    REF_LAYER = 31            # LightBurn tool layer T2: shown, never sent to the laser

    def _default_layer(self, color):
        remembered = self.s.get("color_map", {}).get(color)
        if remembered in ("skip", "ref"):
            return remembered
        if any(l["index"] == remembered for l in self.layers):
            return remembered
        usable = [l for l in self.layers if l["mode"] != "Tool"]
        lines = [l for l in usable if l["mode"] == "Line" and l["output"]] or usable
        cut = [l for l in lines if "cut" in l["name"].lower()]
        return (cut or lines)[0]["index"] if lines else 0

    def _layer_choices(self):
        """(label, value) for the colour dropdowns: value = layer index, 'skip' or 'ref'."""
        usable = [l for l in self.layers if l["mode"] != "Tool"]     # T1/T2 never cut
        layer_opts = [(J.layer_label(l), l["index"]) for l in usable] or [(self.NO_PRESET_LABEL, 0)]
        return layer_opts + [(self.SKIP_LABEL, "skip"), (self.REF_LABEL, "ref")]

    def _rebuild_map(self):
        for w in self.map_frame.winfo_children():
            w.destroy()
        self.map_vars = {}
        self.highlight_color = None
        if not self.job:
            return
        colors = sorted(set(self.job.cut_colors))
        choices = self._layer_choices()
        labels = [lab for lab, _ in choices]
        for c in colors:
            row = ttk.Frame(self.map_frame)
            row.pack(fill="x", pady=1)
            sw = tk.Canvas(row, width=18, height=14, highlightthickness=1, highlightbackground="#888",
                           cursor="hand2")
            sw.create_rectangle(0, 0, 20, 16, fill=c, outline=c)
            sw.pack(side="left")
            sw.bind("<Button-1>", lambda e, c=c: self._highlight(c))
            n = self.job.cut_colors.count(c)
            ttk.Label(row, text=f" {n} line{'s' if n != 1 else ''} →").pack(side="left")
            var = tk.StringVar()
            d = self._default_layer(c)
            for lab, val in choices:
                if val == d:
                    var.set(lab)
            cb = ttk.Combobox(row, textvariable=var, values=labels, state="readonly")
            cb.pack(side="left", fill="x", expand=True, padx=4)
            cb.bind("<<ComboboxSelected>>", lambda e, c=c: self._highlight(c))
            cb.bind("<Button-1>", lambda e, c=c: self._highlight(c), add="+")
            self.map_vars[c] = var
        ttk.Label(self.map_frame, text="Click a colour to see its lines on the bed (orange).",
                  foreground="#666").pack(anchor="w")
        self._refresh_buttons()

    def _highlight(self, color):
        self.highlight_color = color
        self.redraw()
        self.root.after(4000, lambda: (setattr(self, "highlight_color", None), self.redraw())
                        if self.highlight_color == color else None)

    def _color_choice(self, color):
        """'skip', 'ref' or a layer index for one cut-line colour (None if not chosen)."""
        var = self.map_vars.get(color)
        if var is None:
            return None
        return dict(self._layer_choices()).get(var.get())

    def _cut_indices(self):
        """LightBurn layer for each cut path (None = left out), from the colour choices."""
        cmap = {}
        for c in self.map_vars:
            v = self._color_choice(c)
            if v is None:
                raise ValueError("Choose a layer (or Don't cut) for every cut-line colour.")
            cmap[c] = v
        idxs = []
        for c in self.job.cut_colors:
            v = cmap.get(c, 0)
            idxs.append(None if v == "skip" else self.REF_LAYER if v == "ref" else v)
        return idxs, cmap

    def export(self, then=None):
        full, info = self.final_transform()
        if full is None:
            return
        if info["warnings"] and not messagebox.askyesno(
                "Warnings", "There are warnings:\n\n" + "\n".join(info["warnings"]) + "\n\nSave anyway?"):
            return
        n_close = len(getattr(self.job, "close_lines", []))
        if n_close and not messagebox.askyesno(
                "Doubled cut lines", f"{n_close} place{'s' if n_close != 1 else ''} in this cut file "
                f"{'have' if n_close != 1 else 'has'} cut lines less than {J.CLOSE_LINE_MM:g} mm apart "
                "(red circles on the bed view).\nThose lines would be cut twice.\n\nSave anyway?"):
            return
        fmt = "lbrn2" if then else self.fmt_var.get()
        try:
            idxs, cmap = self._cut_indices()
        except ValueError as e:
            messagebox.showwarning("Layers", str(e))
            return
        out = os.path.splitext(self.job.path)[0] + "." + fmt
        if os.path.exists(out) and not messagebox.askyesno(
                "Replace file?", f"{os.path.basename(out)} already exists in that folder.\n\nReplace it?"):
            return
        # leave out 'Don't cut' colours (SVG can't hold tool layers, so reference lines are left out too)
        keep = [k for k, ix in enumerate(idxs) if ix is not None and (fmt == "lbrn2" or ix != self.REF_LAYER)]
        n_cut = sum(1 for ix in idxs if ix is not None and ix != self.REF_LAYER)
        if n_cut == 0:
            messagebox.showwarning("Nothing to cut", "Every cut-line colour is set to Don't cut.")
            return
        cuts = [J.apply(full, self.job.cut[k]) for k in keep]
        idxs = [idxs[k] for k in keep]
        marks = J.apply(full, self.job.mark_xy)
        with_marks = fmt == "lbrn2"     # SVG can't target T1, so marks are left out of SVGs
        try:
            if fmt == "svg":
                J.write_svg(out, cuts, [self.job.cut_colors[k] for k in keep], marks, self.job.marks[0].size,
                            self.s["bed_w"], self.s["bed_h"], include_marks=with_marks)
            else:
                J.write_lbrn2(out, cuts, marks, self.job.marks[0].size, self.s["bed_h"],
                              flip_y=bool(self.s["lightburn_flip_y"]), cut_indices=idxs,
                              preset_file=self.s["preset_file"] or None, include_marks=with_marks,
                              tool_names={self.REF_LAYER: "T2"})
        except Exception as e:
            messagebox.showerror("Save failed", str(e))
            return
        self.s["out_format"] = self.fmt_var.get()
        self.s.setdefault("color_map", {}).update(cmap)
        save_settings(self.s)
        allpts = np.vstack(cuts + ([marks - self.job.marks[0].size / 2, marks + self.job.marks[0].size / 2]
                                   if with_marks else []))
        left, top = allpts[:, 0].min(), allpts[:, 1].min()
        lines = [f"Saved {out}"]
        skipped = [c for c, v in cmap.items() if v == "skip"]
        refs = [c for c, v in cmap.items() if v == "ref"]
        if skipped:
            lines.append(f"Left out (not cut): {sum(self.job.cut_colors.count(c) for c in skipped)} lines "
                         f"({', '.join(skipped)}).")
        if refs:
            lines.append(f"On T2, shown but not cut: {sum(self.job.cut_colors.count(c) for c in refs)} lines "
                         f"({', '.join(refs)})." + ("  (SVG: left out.)" if fmt == "svg" else ""))
        if fmt == "svg":
            lines += ["In LightBurn: File > Import, keep the imported group selected,",
                      "set the 3x3 anchor to TOP-LEFT and type:",
                      f"   XPos {left:.3f}   YPos {top:.3f}",
                      "(Import may drop it anywhere - these numbers put it exactly where measured.)",
                      "SVGs have no reg marks: an SVG can't put them on T1, and on a",
                      "normal layer they could get cut."]
        else:
            lines += ["In LightBurn: File > Open (not Import)." + ("" if self.layers else " Apply your preset to layer 00.")]
        lines += ["Set 'Start From' to Absolute Coords."]
        if with_marks:
            lines += ["Check: a T1 reg-mark circle (anchor centre) should show these measured centres:"]
            lines += [f"   X {x:.3f}  Y {y:.3f}" for x, y in marks]
        self.show_result(lines)
        if then:
            self.disconnect()          # LightBurn needs the laser's reply port back
            self.root.after(300, lambda: self._send_to_lightburn(out, start=(then == "cut")))

    def _lightburn_cmd(self, cmd, timeout=3.0):
        """Send one command to LightBurn's local command port; returns its reply or None."""
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            sock.bind(("127.0.0.1", 19841))
            sock.settimeout(timeout)
            sock.sendto(cmd.encode(), ("127.0.0.1", 19840))
            reply, _ = sock.recvfrom(256)
            return reply.decode(errors="replace").strip()
        except OSError:
            return None
        finally:
            sock.close()

    def _send_to_lightburn(self, path, start=False):
        reply = self._lightburn_cmd(f"LOADFILE:{path}")
        if reply is None:
            exe = r"C:\Program Files\LightBurn\SendUDP.exe"
            if os.path.exists(exe) and not start:
                os.spawnl(os.P_NOWAIT, exe, exe, f'"{path}"')
                self.say("Starting LightBurn with the file…")
            else:
                messagebox.showinfo("LightBurn", "Couldn't reach LightBurn - is it running?\n\n"
                                                 f"Open this file in LightBurn:\n{path}")
            return
        self.say(f"LightBurn loaded the file ({reply}). Laser disconnected here.")
        if start:
            # give LightBurn a moment to take over the laser connection, then ask
            self.root.after(2500, self._confirm_and_start)

    def _confirm_and_start(self):
        if not messagebox.askyesno(
                "Start cutting?",
                "The aligned file is open in LightBurn.\n\n"
                "• LightBurn shows the laser as Ready\n"
                "• Start From is set to Absolute Coords\n"
                "• Lid closed, material in place\n\nStart the cut now?"):
            self.say("Cut not started. You can press Start in LightBurn yourself.")
            return
        reply = self._lightburn_cmd("START", timeout=5)
        if reply is None:
            messagebox.showwarning("LightBurn", "LightBurn didn't answer the Start command.\n"
                                                "Press Start in LightBurn yourself.")
        else:
            self.say(f"LightBurn: {reply} - cutting started.")

    # ---------------------------------------------------------------- camera: panel + live view
    def _build_camera(self, body):
        cf = ttk.Frame(body, padding=(6, 8, 0, 8), width=CAM_W + 12)
        cf.pack(side="right", fill="y")
        cf.pack_propagate(False)
        ttk.Label(cf, text="Camera", font=("Segoe UI", 10, "bold")).pack(anchor="w")
        r1 = ttk.Frame(cf)
        r1.pack(fill="x", pady=(2, 4))
        self.cam_btn = ttk.Button(r1, text="Start camera", command=self.toggle_camera)
        self.cam_btn.pack(side="left")
        ttk.Button(r1, text="Picture…", command=self.camera_settings).pack(side="left", padx=3)
        ttk.Button(r1, text="Calibrate…", command=self.open_calibration).pack(side="left")
        self.cam_lbl = tk.Label(cf, bg="#111", width=CAM_W, height=int(CAM_W * 16 / 9), cursor="crosshair",
                                text="camera off", fg="#777")
        self.cam_lbl.pack(anchor="n")
        self.cam_lbl.bind("<Button-1>", self.on_camera_click)
        r2 = ttk.Frame(cf)
        r2.pack(fill="x", pady=(4, 0))
        self.zoom_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(r2, text="Zoom 3x", variable=self.zoom_var).pack(side="left")
        self.check_btn = ttk.Button(r2, text="Check camera", command=lambda: self.check_camera())
        self.check_btn.pack(side="right")
        self.cam_info = ttk.Label(cf, text="", justify="left", font=("Consolas", 9))
        self.cam_info.pack(anchor="w", pady=(4, 0))
        self.cal_info = ttk.Label(cf, text="", wraplength=CAM_W, justify="left")
        self.cal_info.pack(anchor="w", pady=(4, 0))
        ttk.Label(cf, text="Click the picture to move that spot under the crosshair.",
                  foreground="#666", wraplength=CAM_W).pack(anchor="w", pady=(4, 0))
        self._show_cal_status()
        if K is None:
            self.cam_btn.state(["disabled"])
            self.cam_info.config(text="Camera needs OpenCV:\npy -m pip install opencv-python")

    def _show_cal_status(self):
        if K is None:
            return
        sc, of = self.s.get("cam_scale_ok"), self.s.get("cam_offset_ok")
        if sc:
            d = K.describe_M(self.model.M)
            t1 = f"Scale: {d['mm_per_px']:.4f} mm/pixel, turned {d['angle']:+.1f}°"
        else:
            t1 = "Scale: NOT calibrated (Calibrate… Step 2)"
        if of:
            t2 = f"Offset: X {self.model.C[0]:+.3f}  Y {self.model.C[1]:+.3f} mm {self.s.get('cam_offset_note', '')}"
        else:
            t2 = (f"Offset: estimate only (X {self.model.C[0]:+.1f}, Y {self.model.C[1]:+.1f}) - "
                  "do Calibrate… Step 3 before cutting")
        self.cal_info.config(text=t1 + "\n" + t2, foreground="#2b8a3e" if sc and of else "#c92a2a")

    def toggle_camera(self):
        if self.cam is not None:
            self.cam.close()
            self.cam = None
            self.cam_btn.config(text="Start camera")
            self.cam_lbl.config(image="", text="camera off")
            self.photo = None
            self.redraw()
            return
        try:
            w, h = (int(v) for v in str(self.s["cam_size"]).lower().split("x"))
            if self.simulate:
                cam = K.SimulatedCamera(self.sim_laser, rotate=int(self.s["cam_rotate"]))
                cam.dots = list(getattr(self, "sim_world", []))
            else:
                cam = K.Camera(int(self.s["cam_index"]), (w, h), self.s["cam_format"], int(self.s["cam_rotate"]))
            self.say("Starting camera…")
            self.root.update_idletasks()
            raw = cam.open()
        except Exception as e:
            messagebox.showerror("Camera", str(e))
            return
        rot = int(self.s["cam_rotate"]) in (90, 270)
        self.cam_size = (raw[1], raw[0]) if rot and not self.simulate else raw
        p0 = np.array(self.cam_size, float) / 2
        if np.abs(self.model.p0 - p0).max() > 0.5:
            if self.s.get("cam_scale_ok"):
                messagebox.showwarning("Camera", "The picture size or rotation changed since the camera was "
                                                 "calibrated. Please calibrate again.")
            self.model.p0 = p0
            self.s["cam_scale_ok"] = self.s["cam_offset_ok"] = False
            self._show_cal_status()
        self.cam = cam
        self.cam_btn.config(text="Stop camera")
        self.say(f"Camera on: {self.cam_size[0]} x {self.cam_size[1]} picture.")
        self.cam_last = -1
        self.root.after(50, self._cam_tick)
        self.redraw()

    def camera_settings(self):
        if self.cam is None:
            self.say("Start the camera first.")
        elif sys.platform == "win32":
            self.cam.settings_dialog()
        else:
            messagebox.showinfo("Camera picture", "On Linux use:  qv4l2   or   v4l2-ctl --list-ctrls")

    def _mark_px(self):
        """Expected diameter of a reg mark in pixels."""
        size = self.job.marks[0].size if self.job else 6.35
        return size / self.model.mm_per_px

    def _cam_tick(self):
        if self.cam is None:
            return
        f, stamp, cnt = self.cam.latest()
        if f is not None and cnt != self.cam_last:
            self.cam_last = cnt
            self._show_frame(f)
            if not self._det_busy:
                self._det_busy = True
                dpx = self._mark_px() if self.s.get("cam_scale_ok") else None
                threading.Thread(target=self._detect_live, args=(f, dpx), daemon=True).start()
        if getattr(self.cam, "error", None):
            self.say(self.cam.error)
        self.root.after(120, self._cam_tick)

    def _detect_live(self, f, dpx):
        try:
            if dpx is None:                      # scale not known yet (new camera/size): look for any dot
                short = min(f.shape[:2])
                self.live_dots = K.find_dots(f, 15, short * 0.5)
            else:
                self.live_dots = K.find_dots(f, dpx * 0.6, dpx * 1.5)
        except Exception:
            self.live_dots = []
        self._det_busy = False

    CAM_H_MAX = 600            # tallest the camera picture may be on screen

    def _view_R(self):
        """How the picture is turned on screen so it lines up with the bed view (X right, front down).
        'auto' (default) takes it from calibration Step 2, so any camera angle works - even a round
        endoscope picture at -135 degrees. A number in Settings turns it by that many degrees instead."""
        turn = str(self.s.get("cam_view_turn", "auto")).strip().lower()
        if turn in ("", "auto"):
            if self.s.get("cam_scale_ok"):
                U, _, Vt = np.linalg.svd(self.model.M)
                return U @ Vt                      # nearest pure rotation (or mirror) to the calibration
            return np.eye(2)
        th = math.radians(float(turn))
        return np.array([[math.cos(th), -math.sin(th)], [math.sin(th), math.cos(th)]])

    def _show_frame(self, f):
        h, w = f.shape[:2]
        p0 = self.model.p0
        R = self._view_R()
        corners = np.array([[0, 0], [w, 0], [w, h], [0, h]], float) - p0
        rc = corners @ R.T
        bw = rc[:, 0].max() - rc[:, 0].min()
        bh = rc[:, 1].max() - rc[:, 1].min()
        base = min(CAM_W / bw, self.CAM_H_MAX / bh)
        W_out, H_out = CAM_W, int(min(self.CAM_H_MAX, math.ceil(bh * base)))
        sc = base * (3.0 if self.zoom_var.get() else 1.0)
        c_out = np.array([W_out / 2, H_out / 2])
        # q = sc * R (p - p0) + c_out ; shrink first when scaling down a lot (cleaner picture)
        pre = 1.0
        src = f
        if sc < 0.6:
            pre = min(1.0, sc * 1.5)
            src = cv2.resize(f, None, fx=pre, fy=pre, interpolation=cv2.INTER_AREA)
        A = np.zeros((2, 3))
        A[:, :2] = (sc / pre) * R
        A[:, 2] = c_out - sc * (R @ p0)
        small = cv2.warpAffine(src, A, (W_out, H_out), flags=cv2.INTER_LINEAR, borderValue=(17, 17, 17))
        self.cam_view = (R, sc, c_out)

        def P(p):
            q = sc * (R @ (np.asarray(p, float) - p0)) + c_out
            return int(round(q[0])), int(round(q[1]))
        # crosshair = camera centre
        cx, cy = P(p0)
        cv2.line(small, (cx - 18, cy), (cx + 18, cy), (0, 0, 255), 1)
        cv2.line(small, (cx, cy - 18), (cx, cy + 18), (0, 0, 255), 1)
        # where the next mark should be
        if self.job and self.head and self.s.get("cam_scale_ok"):
            order = self.order()
            k = len(self.measured)
            if k < len(order):
                _, _, _, om = self.oriented()
                pm = J.apply(self.placement(), om[[order[k]]])[0]
                pp = self.model.to_pixel(self.head, pm)
                r = max(6, int(self._mark_px() / 2 * sc) + 6)
                qx, qy = P(pp)
                if -r < qx < W_out + r and -r < qy < H_out + r:
                    cv2.circle(small, (qx, qy), r, (230, 130, 30), 1, cv2.LINE_AA)
        info = f"{self.cam.fps:4.1f} fps"
        dots = list(self.live_dots)
        if dots:
            near = K.nearest_dot(dots, p0)
            for d in dots:
                col = (0, 255, 0) if d is near else (0, 160, 0)
                cv2.circle(small, P(d.xy), max(3, int(d.d / 2 * sc)), col, 2 if d is near else 1, cv2.LINE_AA)
            off = self.model.M @ (near.xy - p0)
            info += f"   dot {near.d * self.model.mm_per_px:.2f} mm"
            if self.s.get("cam_scale_ok"):
                info += f"\nfrom crosshair  X {off[0]:+7.3f}  Y {off[1]:+7.3f} mm"
                if self.head:
                    mx, my = self.model.to_machine(self.head, near.xy)
                    info += f"\ndot at  X {mx:8.3f}  Y {my:8.3f} mm"
        else:
            info += "   no mark in view"
        self.cam_info.config(text=info)
        rgb = cv2.cvtColor(small, cv2.COLOR_BGR2RGB)
        self.photo = tk.PhotoImage(data=b"P6 %d %d 255 " % (rgb.shape[1], rgb.shape[0]) + rgb.tobytes(),
                                   format="PPM")
        self.cam_lbl.config(image=self.photo, text="", width=rgb.shape[1], height=rgb.shape[0])

    def on_camera_click(self, e):
        if self.cam is None or self.cam_view is None:
            return
        R, sc, c_out = self.cam_view
        p = self.model.p0 + R.T @ ((np.array([e.x, e.y], float) - c_out) / sc)
        if self.calib is not None and self.calib.wants_click(p):
            return
        if not self.laser or self.head is None:
            messagebox.showinfo("Camera", "Connect to the laser first - then clicking the picture moves the head.")
            return
        if not self.s.get("cam_scale_ok"):
            messagebox.showinfo("Camera", "Click-to-move needs the camera scale first, so the app knows which way "
                                          "and how far the picture moves.\n\nOpen Calibrate… and do Step 2 "
                                          "(any black dot anywhere in the picture). It takes about 20 seconds.")
            return
        hx, hy = np.asarray(self.head) + self.model.M @ (p - self.model.p0)
        self.goto(hx, hy, "Clicked spot is now under the crosshair.")

    # ---------------------------------------------------------------- camera: measuring (worker thread)
    def _post(self, fn, arg=None):
        """Run fn(arg) on the window's thread (from the worker thread)."""
        self.worker.results.put((fn, arg, None))

    def _check_stop(self):
        if self.stop_evt.is_set():
            raise Stopped()

    def _w_goto(self, x, y):
        """Worker: absolute move, refuses to leave the safe area, reports the head position."""
        self._check_stop()
        if not self._in_bed(x, y):
            raise LaserError(f"Refused: ({x:.1f}, {y:.1f}) is outside the safe bed area.")
        before = self.laser.position_um()
        f, _, _ = self.cam.latest() if self.cam is not None else (None, 0, 0)
        t0 = time.time()
        a = float(self.s.get("approach_mm", 1.0))
        if a > 0 and self._in_bed(x - a, y - a):
            # always arrive the same way (from the back-left, moving +X then +Y), so belt slack /
            # backlash is the same for every mark and every calibration burn
            self.laser.goto_um(int(round((x - a) * 1000)), int(round((y - a) * 1000)))
        p = self.laser.goto_um(int(round(x * 1000)), int(round(y * 1000)))
        head = (p[0] / 1000, p[1] / 1000)
        moved = math.hypot(p[0] - before[0], p[1] - before[1]) / 1000
        tm = self.timing
        tm["move_s"] += time.time() - t0
        tm["move_mm"] += abs(p[0] - before[0]) / 1000 + abs(p[1] - before[1]) / 1000   # X then Y
        if moved > 0.01 and f is not None:
            self._ref = (K.small_gray(f), moved)        # picture from before the move
        self._post(self._set_head, head)
        return np.array(head)

    def _set_head(self, head):
        self.head = tuple(head)
        self._show_pos()
        self.redraw()
        self._check_speed_error()

    def _check_speed_error(self):
        err = getattr(self.laser, "speed_error", None)
        if err and not getattr(self, "_speed_warned", False):
            self._speed_warned = True
            messagebox.showwarning("Travel speed", "The laser did not accept the travel speed command "
                                   f"({err}).\n\nMoves still work, at the speed of the last job. "
                                   "Set both speeds to 0 in Settings to stop trying.")

    def _w_frames(self, n):
        """n pictures taken with the head (and camera) standing still at the new spot.
        The camera can deliver pictures late, so wait until the picture has changed from before the
        move AND has stopped changing."""
        ref, moved = getattr(self, "_ref", None) or (None, 0.0)
        self._ref = None
        t0 = time.time()
        frames, info = self.cam.still_frames(n, time.time() + float(self.s["cam_settle"]),
                                             ref if moved > 0.4 else None)
        self.timing["wait_s"] += time.time() - t0
        if info:
            self._post(self.say, info)
        return frames

    def _w_locate(self, target, size_mm, here_first, probe=False):
        """Worker: find the mark expected at machine point `target`, centre the camera on it and
        measure it. Returns (machine x, y), details."""
        m = self.model
        dpx = size_mm / m.mm_per_px
        lo, hi = dpx * 0.65, dpx * 1.45
        target = np.asarray(target, float)
        w, h = self.cam_size
        # view size in mm; step between search spots ~half a view
        step = 0.5 * min(w, h) * m.mm_per_px
        R = float(self.s["cam_search_mm"])
        spots = [(0.0, 0.0)]
        ring = 1
        while ring * step <= R + 1e-6:
            n = 8 * ring
            for k in range(n):
                a = 2 * math.pi * k / n
                spots.append((ring * step * math.cos(a), ring * step * math.sin(a)))
            ring += 1
        head = np.array(self.head, float)
        if here_first:
            # mark 1: the user put the camera over (or near) it - look here first, search around here
            target = m.to_machine(head, m.p0)
        found = None
        for si, (ox, oy) in enumerate(spots):
            look_at = target + (ox, oy)
            if not (si == 0 and here_first):
                head = self._w_goto(*(look_at - m.C))
            if si:
                self._post(self.say, f"Searching… spot {si} of {len(spots) - 1}")
            f = self._w_frames(1)[0]
            dots = K.find_dots(f, lo, hi)
            if dots:
                pts = [m.to_machine(head, d.xy) for d in dots]
                j = int(np.argmin([np.hypot(*(p - target)) for p in pts]))
                found = pts[j]
                pre_px = dots[j].xy
                break
        if found is None:
            raise LookupError(f"No mark found within {R:.0f} mm of where it should be.")
        # centre on it and measure (twice if the first move didn't land it close to the centre)
        info = {}
        move_err = []          # camera health: how far the dot landed from where the move should put it
        for it in range(3):
            head = self._w_goto(*(found - m.C))
            frames = self._w_frames(3)
            dot, spread = K.measure_dot(frames, lo, hi, m.p0, max_dist=dpx)
            if dot is None:
                raise LookupError("Lost the mark while centring on it - check the lighting.")
            moved_px = float(np.hypot(*(pre_px - m.p0)))
            if 60 <= moved_px <= 350:          # a real move, but near the centre (little lens distortion)
                move_err.append(float(np.hypot(*(dot.xy - m.p0))) / moved_px)
            pre_px = dot.xy
            off = m.M @ (dot.xy - m.p0)
            found = head + m.C + off
            info = {"d_mm": dot.d * m.mm_per_px, "spread_mm": spread * m.mm_per_px,
                    "fit_mm": dot.fit_dx * m.mm_per_px, "off_mm": float(np.hypot(*off)), "moves": it + 1,
                    "move_err": move_err}
            if np.hypot(*off) < 0.05:
                break
        # confirm: measure again (camera standing still) until two readings agree, so the mark
        # is never accepted from a single, possibly shaky look
        n = max(1, int(self.s.get("cam_frames", 6)))
        tol = float(self.s.get("cam_confirm_mm", 0.02))
        readings = [found]
        for attempt in range(5):
            self._post(self.say, f"Confirming the mark… (reading {attempt + 2})")
            time.sleep(float(self.s.get("cam_settle", 0.35)))
            dot, spread = K.measure_dot(self._w_frames(n), lo, hi, m.p0, max_dist=dpx)
            if dot is None:
                continue
            readings.append(head + m.C + m.M @ (dot.xy - m.p0))
            if np.hypot(*(readings[-1] - readings[-2])) <= tol:
                break
        else:
            raise LookupError("The mark's position kept changing between readings - is the sheet or "
                              "the camera moving? Check the mount and that the sheet lies flat.")
        found = (readings[-1] + readings[-2]) / 2
        info["confirm_mm"] = float(np.hypot(*(readings[-1] - readings[-2])))
        info["readings"] = len(readings)
        self._post(self.say, f"Mark confirmed: 2 readings agree within {info['confirm_mm']:.3f} mm.")
        time.sleep(float(self.s.get("cam_hold", 0.5)))      # let it show before moving on
        if probe:
            # camera health: step 3 mm diagonally and check the dot lands where the calibration says.
            # A camera that got twisted, tilted or changed height misses by a few % of the step.
            step = np.array([3.0, 3.0])
            h2 = self._w_goto(*(head + step))
            expect = m.to_pixel(h2, found)
            d2, _ = K.measure_dot(self._w_frames(2), lo, hi, expect, max_dist=dpx)
            if d2 is not None:
                info["probe_err"] = float(np.hypot(*(d2.xy - expect)) / max(1.0, np.hypot(*(expect - m.p0))))
            self._w_goto(*head)
        return found, info

    def stop_motion(self):
        if self.auto or self.worker.busy:
            self.stop_evt.set()
            self.say("Stopping…")
        self.auto = False
        self._refresh_buttons()

    def auto_measure(self):
        self.camera_find(True)

    def camera_find(self, auto):
        if not self.job or not self.laser or self.cam is None or self.worker.busy:
            return
        if not self.s.get("cam_scale_ok"):
            messagebox.showinfo("Camera", "Calibrate the camera first (Calibrate… Step 2).")
            return
        if not self.s.get("cam_offset_ok") and not self.simulate and not getattr(self, "_offset_warned", False):
            self._offset_warned = True
            if not messagebox.askyesno("Camera offset not calibrated",
                                       "The camera-to-laser offset is only an estimate, so the cut would land "
                                       "in the wrong place.\n\nMeasure anyway (for testing)?"):
                return
        if not self._confirm_motion(60):
            return
        order = self.order()
        k = len(self.measured)
        if k >= len(order):
            return
        if (k == 0 and self.s.get("cam_ref") and self.s.get("cam_check_each_job")
                and not getattr(self, "ref_checked", False)):
            self.ref_checked = True
            self.check_camera(then=lambda: self.camera_find(auto))
            return
        self.auto = auto
        if self.timing.get("t0") is None:
            self.timing["t0"] = time.time()
        self.stop_evt.clear()
        _, _, _, om = self.oriented()
        i = order[k]
        here_first = k == 0
        target = J.apply(self.placement(), om[[i]])[0]
        size = self.job.marks[i].size
        self.say(f"Camera: looking for mark {k + 1}…")

        def done(res):
            pos, info = res
            self.measured[i] = (float(pos[0]), float(pos[1]))
            self.mark_info[i] = info
            self.say(f"Mark {k + 1} at X {pos[0]:.3f}, Y {pos[1]:.3f}  (dot {info['d_mm']:.2f} mm, "
                     f"steady ±{info['spread_mm']:.3f} mm)")
            if abs(info["d_mm"] / size - 1) > 0.15:
                self.auto = False
                messagebox.showwarning("Check this mark", f"The dot found is {info['d_mm']:.2f} mm across; "
                                       f"the PDF's mark is {size:.2f} mm.\nIs it the right mark? Undo it if not.")
            if len(self.measured) == len(self.job.marks):
                self._camera_health()
                tm = self.timing
                total = time.time() - (tm["t0"] or time.time())
                speed = tm["move_mm"] / tm["move_s"] if tm["move_s"] > 0 else 0
                self.health_lines.append(
                    f"  Time: {total:.0f} s total - moving {tm['move_s']:.0f} s ({tm['move_mm']:.0f} mm, "
                    f"~{speed:.0f} mm/s incl. stops), waiting for camera {tm['wait_s']:.0f} s.")
            self.update_result()
            self.redraw()
            if self.auto and len(self.measured) < len(self.job.marks):
                self.root.after(50, lambda: self.camera_find(True))
            else:
                self.auto = False
                self._refresh_buttons()

        def failed(e):
            self.auto = False
            self._refresh_buttons()
            if isinstance(e, Stopped):
                self.say("Stopped.")
            elif isinstance(e, LookupError):
                self.say(str(e))
                messagebox.showwarning("Mark not found", f"Mark {k + 1}: {e}\n\nJog the camera until the mark is "
                                       "in the picture and press 'Find this mark' - or click the mark in the "
                                       "picture first.")
            else:
                self._laser_error(e)
        self._refresh_buttons()
        last = k == len(order) - 1
        self.worker.submit(lambda: self._w_locate(target, size, here_first, probe=last), done, failed)

    # ---------------------------------------------------------------- camera: health checks
    SIZE_TOL = 0.04          # dots look >4 % bigger/smaller than usual -> camera height changed?
    MOVE_TOL = 0.03          # centring moves land >3 % (of the move) off -> camera turned / height changed?
    REF_TOL = 0.10           # reference dot more than this far (mm) from where it was -> camera moved

    def _camera_health(self):
        """After every camera-measured job: compare dot size and centring accuracy with what this camera
        usually gives. Catches a camera that sagged, tilted or got twisted. (A camera that only slid
        sideways looks normal here - the reference dot check catches that.)"""
        infos = [self.mark_info[i] for i in self.measured if i in self.mark_info]
        self.health_lines = []
        if len(infos) < 2:
            return
        size = {i: self.job.marks[i].size for i in self.mark_info}
        ratios = [self.mark_info[i]["d_mm"] / size[i] for i in self.mark_info if i in self.measured]
        moves = [inf["probe_err"] for inf in infos if "probe_err" in inf] or \
            [e for inf in infos for e in inf.get("move_err", [])]
        h = dict(self.s.get("cam_health") or {})
        warn = []
        r = float(np.median(ratios))
        if h.get("size") is None:
            h["size"] = r
            txt_size = "dot size: learning what's normal"
        else:
            dev = r / h["size"] - 1
            txt_size = f"dots {100 * dev:+.1f}% vs usual"
            if abs(dev) > self.SIZE_TOL:
                warn.append(f"the marks look {abs(100 * dev):.0f}% {'bigger' if dev > 0 else 'smaller'} than usual "
                            "(camera closer to / further from the material?)")
            else:
                h["size"] = 0.8 * h["size"] + 0.2 * r
        txt_move = ""
        if moves:
            mv = float(np.median(moves))
            base = h.get("move")
            if base is None:
                h["move"] = mv
                txt_move = ", test move: learning"
            else:
                txt_move = f", test move off {100 * mv:.1f}% (usual {100 * base:.1f}%)"
                if mv > max(self.MOVE_TOL, base + 0.02):
                    warn.append(f"a 3 mm test move lands {100 * mv:.0f}% off (camera turned, tilted or changed height?)")
                else:
                    h["move"] = 0.8 * base + 0.2 * mv
        self.s["cam_health"] = h
        save_settings(self.s)
        if warn:
            self.health_lines = ["! CAMERA MAY HAVE MOVED: " + "; ".join(warn) + "."]
            msg = ("Camera check after measuring:\n\n• " + "\n• ".join(warn) +
                   "\n\nThe camera may have been bumped or the mount may be sagging. "
                   + ("Run 'Check camera' (reference dot), or " if self.s.get("cam_ref") else "")
                   + "check the mount and redo Calibrate… (Step 2 and Step 3) before cutting.")
            self.auto = False
            messagebox.showwarning("Camera may have moved", msg)
        else:
            self.health_lines = [f"✓ Camera health: {txt_size}{txt_move}."]

    def _w_dot_near_centre(self):
        """Worker: the dot nearest the crosshair: (machine point, diameter mm)."""
        m = self.model
        short = min(self.cam_size)
        f = self._w_frames(2)[0]
        d = K.nearest_dot(K.find_dots(f, 0.8 / m.mm_per_px, min(15.0 / m.mm_per_px, short * 0.5)), m.p0,
                          max_dist=short * 0.3)
        if d is None:
            raise LookupError("No dot near the crosshair.")
        return m.to_machine(np.array(self.head, float), d.xy), d.d * m.mm_per_px

    def set_reference(self):
        if not (self.cam is not None and self.laser and self.s.get("cam_scale_ok") and self.s.get("cam_offset_ok")):
            messagebox.showinfo("Reference dot", "Connect, start the camera, and finish Calibrate… Step 2 and "
                                                 "Step 3 first - the reference is recorded with a good calibration.")
            return
        if self.worker.busy:
            return
        self.stop_evt.clear()

        def work():
            pt, dmm = self._w_dot_near_centre()
            pos, info = self._w_locate(pt, dmm, False)
            return pos, info["d_mm"]

        def done(r):
            pos, dmm = r
            self.s["cam_ref"] = {"x": float(pos[0]), "y": float(pos[1]), "d": float(dmm)}
            save_settings(self.s)
            self.say(f"Reference dot saved at X {pos[0]:.3f}, Y {pos[1]:.3f} ({dmm:.2f} mm).")
            if self.calib:
                self.calib.refresh()
            self._refresh_buttons()

        def failed(e):
            if isinstance(e, LookupError):
                messagebox.showwarning("Reference dot", f"{e}\nJog the camera so the reference dot is near "
                                                        "the red crosshair, then try again.")
            elif not isinstance(e, Stopped):
                self._laser_error(e)
        self.say("Measuring the reference dot…")
        self.worker.submit(work, done, failed)

    def check_camera(self, then=None):
        """Measure the reference dot: has the camera moved since it was recorded?"""
        ref = self.s.get("cam_ref")
        if not ref:
            messagebox.showinfo("Check camera", "No reference dot yet (optional).\n\nIt's set up in "
                                                "Calibrate… Step 4: any small black dot that never moves, "
                                                "e.g. on the machine frame. Until then, the app still checks "
                                                "the camera automatically after every job.")
            return
        if self.cam is None or not self.laser or self.worker.busy:
            self.say("Connect and start the camera first.")
            return
        if not self._confirm_motion(100):
            return
        self.stop_evt.clear()
        start = np.array(self.head, float)
        target = np.array([ref["x"], ref["y"]])

        def work():
            pos, info = self._w_locate(target, ref["d"], False)
            if then is not None:
                self._w_goto(*start)                 # back to where the user left the camera
            return pos, info

        def done(r):
            pos, info = r
            err = pos - target
            dist = float(np.hypot(*err))
            size_dev = info["d_mm"] / ref["d"] - 1
            self.s["cam_ref_last"] = {"t": time.strftime("%Y-%m-%d %H:%M"), "err": dist}
            save_settings(self.s)
            if abs(size_dev) > self.SIZE_TOL:
                messagebox.showwarning("Check camera", f"The reference dot looks {abs(100 * size_dev):.0f}% "
                                       f"{'bigger' if size_dev > 0 else 'smaller'} than when it was recorded: the "
                                       "camera's height or angle has changed.\n\nCheck the mount, then redo "
                                       "Calibrate… Step 2 and Step 3.")
                return
            if dist <= self.REF_TOL:
                self.say(f"Camera OK: reference dot within {dist:.3f} mm.")
                if then is not None:
                    self.root.after(100, then)
                return
            if messagebox.askyesno("Camera has moved",
                                   f"The reference dot is {dist:.2f} mm from where it was recorded "
                                   f"(X {err[0]:+.2f}, Y {err[1]:+.2f} mm): the camera has shifted.\n\n"
                                   "Correct the camera offset now?\n(Then check the mount is secure.)"):
                self.model.C = self.model.C - err
                self.s["cam_model"] = self.model.to_dict()
                self.s["cam_offset_note"] = f"(corrected from reference dot {time.strftime('%m-%d %H:%M')})"
                save_settings(self.s)
                self._show_cal_status()
                self.say(f"Camera offset corrected by {dist:.2f} mm.")
                if then is not None:
                    self.root.after(100, then)
            else:
                self.say("Camera offset not changed.")

        def failed(e):
            if isinstance(e, LookupError):
                messagebox.showwarning("Check camera", f"Couldn't find the reference dot: {e}\n\nIf the camera "
                                       "moved a lot, redo Calibrate… Step 3, then set the reference again.")
            elif not isinstance(e, Stopped):
                self._laser_error(e)
        self.say("Checking the camera on the reference dot…")
        self.worker.submit(work, done, failed)

    # ---------------------------------------------------------------- camera: calibration
    def open_calibration(self):
        if K is None:
            return
        if self.calib is not None:
            self.calib.win.lift()
            return
        self.calib = Calibration(self)

    # ---------------------------------------------------------------- settings
    def open_settings(self):
        w = tk.Toplevel(self.root)
        w.title("Settings")
        w.transient(self.root)
        fields = [("Scramble key", "magic"), ("Bed width mm", "bed_w"), ("Bed depth mm", "bed_h"),
                  ("Red-dot offset X mm", "pointer_dx"), ("Red-dot offset Y mm", "pointer_dy"),
                  ("Camera number", "cam_index"), ("Camera picture size", "cam_size"),
                  ("Camera format (mjpg / yuyv)", "cam_format"),
                  ("Picture turn on screen (auto, or degrees)", "cam_view_turn"),
                  ("Mark search distance mm", "cam_search_mm"), ("Wait after a move, s", "cam_settle"),
                  ("Pictures averaged per reading", "cam_frames"),
                  ("Readings must agree within, mm", "cam_confirm_mm"),
                  ("Pause after each mark, s", "cam_hold"),
                  ("Same-direction approach, mm (0 = off)", "approach_mm"),
                  ("Cut nudge X mm (+ = right)", "nudge_x"),
                  ("Cut nudge Y mm (+ = toward front)", "nudge_y"),
                  ("Travel speed between marks, mm/s (0 = off)", "travel_speed"),
                  ("Precise move speed (under 5 mm), mm/s (0 = off)", "precise_speed")]
        text_keys = ("magic", "cam_size", "cam_format", "cam_view_turn")
        int_keys = ("cam_index", "cam_rotate", "cam_frames")
        vars_ = {}
        for r, (lbl, key) in enumerate(fields):
            ttk.Label(w, text=lbl).grid(row=r, column=0, sticky="w", padx=8, pady=3)
            v = tk.StringVar(value=str(self.s[key]))
            ttk.Entry(w, textvariable=v, width=12).grid(row=r, column=1, padx=8)
            vars_[key] = v
        yv = tk.BooleanVar(value=bool(self.s["lightburn_flip_y"]))
        ttk.Checkbutton(w, text="Flip Y in the LightBurn file (leave OFF - only for machines with a front origin)",
                        variable=yv).grid(row=len(fields), column=0, columnspan=2, sticky="w", padx=8, pady=6)
        ttk.Label(w, text="Red-dot offset: where the red dot lands relative to the laser beam.\n"
                          "Leave 0 if your red dot shines through the lens (most Thunder machines).",
                  foreground="#555").grid(row=len(fields) + 1, column=0, columnspan=2, padx=8, sticky="w")

        def ok():
            try:
                old_cam = (self.s["cam_index"], self.s["cam_size"], self.s["cam_format"], self.s["cam_rotate"])
                for key, v in vars_.items():
                    val = v.get().strip()
                    self.s[key] = val.lower() if key in text_keys[1:] else val if key == "magic" else \
                        int(float(val)) if key in int_keys else float(val)
                int(str(self.s["magic"]), 0)
                if self.s["cam_format"] not in ("mjpg", "yuyv"):
                    raise ValueError
                [int(x) for x in self.s["cam_size"].split("x")]
                if self.s["cam_view_turn"] in ("",):
                    self.s["cam_view_turn"] = "auto"
                if self.s["cam_view_turn"] != "auto":
                    float(self.s["cam_view_turn"])
            except ValueError:
                messagebox.showerror("Settings", "Please check the values (numbers; size like 1920x1080; "
                                                 "format mjpg or yuyv; picture turn: auto or a number of degrees).", parent=w)
                return
            if not (0 <= self.s["travel_speed"] <= 1000 and 0 <= self.s["precise_speed"] <= 1000):
                messagebox.showerror("Settings", "Speeds must be between 0 and 1000 mm/s.", parent=w)
                return
            self.s["lightburn_flip_y"] = yv.get()
            save_settings(self.s)
            self._apply_speeds()
            w.destroy()
            if self.cam is not None and old_cam != (self.s["cam_index"], self.s["cam_size"],
                                                    self.s["cam_format"], self.s["cam_rotate"]):
                self.toggle_camera()
                self.toggle_camera()          # restart with the new camera settings
            self.redraw()
        ttk.Button(w, text="OK", command=ok).grid(row=len(fields) + 2, column=1, pady=8, sticky="e", padx=8)

    def on_close(self):
        self.s["ip"] = self.ip_var.get().strip()
        self.s["step"] = self._step() or 1.0
        save_settings(self.s)
        self.stop_evt.set()
        if self.cam is not None:
            self.cam.close()
        if self.laser:
            self.laser.close()
        self.root.destroy()

# ------------------------------------------------------------ camera calibration window

SPOTS = [(0, 0), (20, 0), (0, 20), (20, 20), (10, 10)]     # burn spots, mm from the first one


class Calibration:
    """Step 2: pixel size + camera rotation (jog test over one dot).
    Step 3: camera-to-beam offset from pulse burns."""

    def __init__(self, app):
        self.app = app
        a = app
        self.win = w = tk.Toplevel(a.root)
        w.title("Camera calibration")
        w.transient(a.root)
        w.resizable(False, False)
        w.protocol("WM_DELETE_WINDOW", self.close)
        for key, d in (("<Left>", (-1, 0)), ("<Right>", (1, 0)), ("<Up>", (0, -1)), ("<Down>", (0, 1))):
            w.bind(key, lambda e, d=d: a.jog(*d))
            w.bind("<Shift-" + key[1:], lambda e, d=d: a.jog(*d, step=0.01))
        self.burns = []            # dicts: B (machine), before frame, C result
        self.origin = None
        self.click_for = None

        f0 = ttk.LabelFrame(w, text="Step 1 - camera orientation  (optional, for round cameras)", padding=8)
        f0.pack(fill="x", padx=8, pady=(8, 4))
        r0 = ttk.Frame(f0)
        r0.pack(fill="x")
        self.arrow = tk.Canvas(r0, width=74, height=74, highlightthickness=0, bg="#f1f3f5")
        self.arrow.pack(side="left", padx=(0, 8))
        c0 = ttk.Frame(r0)
        c0.pack(side="left", fill="x", expand=True)
        ttk.Label(c0, wraplength=430, justify="left", text=(
            "Put a black dot in the camera picture and press Measure. The arrow shows which way to turn "
            "the camera in its holder to line it up square with the machine. Turn it, press Measure again, "
            "repeat until it says lined up. (Only for a tidy picture - accuracy doesn't depend on it.)")
                  ).pack(anchor="w")
        rr = ttk.Frame(c0)
        rr.pack(fill="x", pady=(4, 0))
        ttk.Button(rr, text="Measure camera angle", command=self.run_orient).pack(side="left")
        self.orient_lbl = ttk.Label(rr, text="", wraplength=290, justify="left")
        self.orient_lbl.pack(side="left", padx=8)
        self._draw_arrow(None)

        f1 = ttk.LabelFrame(w, text="Step 2 - camera scale  (once, and after moving the camera)", padding=8)
        f1.pack(fill="x", padx=8, pady=4)
        ttk.Label(f1, wraplength=520, justify="left", text=(
            "Put a printed reg mark (any black dot 3-10 mm) where the camera can see it - anywhere in the "
            "picture. The head centres on it, moves 3 mm around it, and works out the pixel size and how "
            "the camera is turned.")).pack(anchor="w")
        r = ttk.Frame(f1)
        r.pack(fill="x", pady=(6, 0))
        self.scale_btn = ttk.Button(r, text="Measure scale", command=self.run_scale)
        self.scale_btn.pack(side="left")
        self.scale_lbl = ttk.Label(r, text="", wraplength=400, justify="left")
        self.scale_lbl.pack(side="left", padx=8)

        f2 = ttk.LabelFrame(w, text="Step 3 - where the laser fires  (pulse burns)", padding=8)
        f2.pack(fill="x", padx=8, pady=4)
        ttk.Label(f2, wraplength=520, justify="left", text=(
            "The app burns 5 tiny dots and looks at each one with the camera. That tells it exactly "
            "where the laser fires compared with the camera.\n\n"
            "Before you start:\n"
            "   •  Stick a piece of masking tape or card (palm-sized) on the bed under the head.\n"
            "   •  On the laser's panel, set the pulse power low (about 10-15 %).")).pack(anchor="w")
        er = ttk.Frame(f2)
        er.pack(fill="x", pady=(6, 0))
        ttk.Label(er, text="Rough camera position from the laser beam:  X").pack(side="left")
        g = a.model.C if a.s.get("cam_offset_ok") else a.s.get("cam_offset_guess", [0.0, 43.2])
        self.est_x = tk.StringVar(value=f"{float(g[0]):.1f}")
        self.est_y = tk.StringVar(value=f"{float(g[1]):.1f}")
        ttk.Entry(er, textvariable=self.est_x, width=6).pack(side="left", padx=2)
        ttk.Label(er, text="Y").pack(side="left")
        ttk.Entry(er, textvariable=self.est_y, width=6).pack(side="left", padx=2)
        ttk.Label(er, text="mm   (+X = right, +Y = toward the front; a ruler guess is fine)",
                  foreground="#666").pack(side="left")
        self.instr = tk.Label(f2, wraplength=520, justify="left", anchor="w", font=("Segoe UI", 11, "bold"),
                              fg="#1c4f8a", bg="#e7f0fb", padx=8, pady=8)
        self.instr.pack(fill="x", pady=(8, 6))
        r2 = ttk.Frame(f2)
        r2.pack(fill="x")
        self.main_btn = ttk.Button(r2, text="", command=self.next_action)
        self.main_btn.pack(side="left", ipadx=6, ipady=3)
        if a.simulate:
            ttk.Button(r2, text="(simulated PULSE)", command=lambda: a.cam.pulse()).pack(side="left", padx=4)
        ttk.Button(r2, text="Start over", command=self.restart).pack(side="right")
        self.prog_lbl = ttk.Label(f2, text="", justify="left")
        self.prog_lbl.pack(anchor="w", pady=(8, 0))
        r3 = ttk.Frame(f2)
        r3.pack(fill="x", pady=(6, 0))
        self.save_btn = ttk.Button(r3, text="Save", command=self.save_offset)
        self.save_btn.pack(side="left")
        self.off_lbl = ttk.Label(r3, text="", wraplength=430, justify="left")
        self.off_lbl.pack(side="left", padx=8)
        self.saved = False

        f4 = ttk.LabelFrame(w, text="Step 4 - reference dot  (optional)", padding=8)
        f4.pack(fill="x", padx=8, pady=4)
        ttk.Label(f4, wraplength=520, justify="left", text=(
            "A small black dot (3-10 mm) that never moves - on the machine frame or a tag screwed down, "
            "not on the honeycomb. Do this right after Step 3. Then 'Check camera' tells you in a few "
            "seconds if the camera has been bumped, and can fix the offset without burns.")).pack(anchor="w")
        r4 = ttk.Frame(f4)
        r4.pack(fill="x", pady=(6, 0))
        ttk.Button(r4, text="Set reference dot (under crosshair)", command=a.set_reference).pack(side="left")
        ttk.Button(r4, text="Check camera now", command=lambda: a.check_camera()).pack(side="left", padx=4)
        self.each_var = tk.BooleanVar(value=bool(a.s.get("cam_check_each_job")))
        ttk.Checkbutton(f4, text="Check the camera automatically before every Auto-measure",
                        variable=self.each_var, command=self._each_changed).pack(anchor="w", pady=(4, 0))
        self.ref_lbl = ttk.Label(f4, text="", wraplength=520, justify="left")
        self.ref_lbl.pack(anchor="w", pady=(4, 0))

        f3 = ttk.Frame(w, padding=8)
        f3.pack(fill="x")
        ttk.Label(f3, wraplength=520, justify="left", foreground="#555", text=(
            "Check any time: burn a pulse on scrap, then click the burn in the camera picture - the "
            "crosshair should land exactly on it.")).pack(anchor="w")
        ttk.Button(f3, text="Close", command=self.close).pack(anchor="e")
        self.refresh()

    # ------------------------------------------------------------------
    def ready(self, need_scale=False):
        a = self.app
        if a.cam is None or a.laser is None or a.head is None:
            messagebox.showinfo("Calibration", "Connect the laser and start the camera first.", parent=self.win)
            return False
        if a.worker.busy:
            return False
        if need_scale and not a.s.get("cam_scale_ok"):
            messagebox.showinfo("Calibration", "Do Step 2 (scale) first.", parent=self.win)
            return False
        return True

    def refresh(self):
        a = self.app
        if a.s.get("cam_scale_ok"):
            d = K.describe_M(a.model.M)
            vw, vh = (np.array(a.cam_size or (0, 0)) * d["mm_per_px"])
            self.scale_lbl.config(text=f"{d['mm_per_px']:.4f} mm per pixel, camera turned {d['angle']:+.2f}°"
                                       + (f", view {vw:.0f} x {vh:.0f} mm" if a.cam_size else "")
                                       + (", mirrored" if d["mirrored"] else ""))
        done = [b for b in self.burns if b.get("C") is not None]
        pending = self.burns[-1] if self.burns and self.burns[-1].get("C") is None else None
        n = len(done)
        dots = "".join("●" if k < n else "○" for k in range(len(SPOTS)))
        Cs = self.results()
        self.prog_lbl.config(text=f"Burns done:  {dots}   {n} of {len(SPOTS)}")
        if Cs is not None:
            mean, spread, _ = Cs
            ok = spread <= 0.05
            self.off_lbl.config(text=f"Laser is at X {mean[0]:+.3f}  Y {mean[1]:+.3f} mm from the camera centre.  "
                                     f"Burns agree within {spread:.3f} mm" + (" - good." if ok else " - check the burns."),
                                foreground="#2b8a3e" if ok else "#c92a2a")
        else:
            self.off_lbl.config(text="")
        if not a.s.get("cam_scale_ok"):
            msg, btn = "Do Step 2 (scale) first.", None
        elif self.saved:
            msg, btn = ("Saved. To check it: burn a pulse on scrap, then click the burn in the camera picture - "
                        "the red crosshair should land right on it."), None
        elif pending is not None and pending.get("confirm"):
            head = ("Couldn't find the burn by itself - the camera is where it should be.\n"
                    if pending.get("auto_failed") else "")
            msg = (f"{head}Burn {n + 1}: check the burn is EXACTLY under the red crosshair (Zoom 3x is on).\n"
                   "If it's off, nudge the head with the arrow keys (0.05 mm; Shift + arrow = 0.01 mm) or "
                   "click the burn in the picture, until it's dead centre. Then press Accept.")
            btn = "✓ Accept - the burn is under the crosshair"
        elif pending is not None:
            msg = (f"Burn {n + 1} of {len(SPOTS)}:  press PULSE on the laser's panel once.\n"
                   "(The laser is right above the spot.)  Then press the button below.")
            btn = "I pressed PULSE - find the burn"
        elif n >= len(SPOTS):
            msg, btn = "All 5 burns done - press Save.", None
        else:
            msg = (f"Burn {n + 1} of {len(SPOTS)}:  press the button below.\n"
                   "The camera looks at a fresh spot on the tape, then the laser moves over it.")
            if n >= 3:
                msg += "\n(3 burns is enough - you can Save now, or do more for a better average.)"
            btn = f"Move to burn spot {n + 1}"
        self.instr.config(text=msg)
        if btn:
            self.main_btn.config(text=btn)
            self.main_btn.state(["!disabled"])
        else:
            self.main_btn.config(text="-")
            self.main_btn.state(["disabled"])
        self.save_btn.state(["!disabled"] if n >= 3 and not self.saved else ["disabled"])
        ref = a.s.get("cam_ref")
        last = a.s.get("cam_ref_last")
        self.ref_lbl.config(text=(f"Reference dot at X {ref['x']:.2f}, Y {ref['y']:.2f} ({ref['d']:.2f} mm)."
                                  + (f"  Last check {last['t']}: {last['err']:.3f} mm." if last else ""))
                            if ref else "No reference dot set - the automatic checks after each job still run.")

    def _each_changed(self):
        self.app.s["cam_check_each_job"] = bool(self.each_var.get())
        save_settings(self.app.s)

    def next_action(self):
        if self.burns and self.burns[-1].get("C") is None:
            if self.burns[-1].get("confirm"):
                self.accept_burn()
            else:
                self.find_burn()
        else:
            self.go_spot()

    def _centre_for_check(self, b, C_guess):
        """Put the burn (as found, or as expected) under the crosshair and let the user confirm or fix it."""
        a = self.app
        a.zoom_var.set(True)
        a.step_var.set("0.05")

        def work():
            return a._w_goto(*(b["B"] - C_guess))

        def done(head):
            b["confirm"] = True
            self.refresh()
            self.win.focus_set()
        a.worker.submit(work, done, self._fail)

    def accept_burn(self):
        a = self.app
        b = self.burns[-1]
        if a.worker.busy:
            return

        def done(p):
            head = np.array(p, float) / 1000
            a.head = tuple(head)
            b["C"] = b["B"] - head                  # burn under the crosshair: beam spot = head + C
            b["coarse"] = False
            b["confirm"] = False
            fix = float(np.hypot(*(b["C"] - b["Cauto"]))) if b.get("Cauto") is not None else None
            self.refresh()
            a.say("Burn accepted" + (f" (you adjusted it by {fix:.3f} mm)." if fix is not None and fix > 0.005
                                     else "."))
        a.worker.submit(lambda: a.laser.position_um(), done, self._fail)

    def results(self):
        good = [b for b in self.burns if b.get("C") is not None]
        fine = [b for b in good if not b.get("coarse")] or good
        if not fine:
            return None
        C = np.array([b["C"] for b in fine])
        mean = C.mean(0)
        return mean, float(np.hypot(*(C - mean).T).max()), len(good)

    def close(self):
        self.app.calib = None
        self.win.destroy()

    # ------------------------------------------------------------------ step 1
    def run_scale(self):
        if not self.ready():
            return
        a = self.app
        if not a._confirm_motion(10):
            return
        a.stop_evt.clear()
        self.scale_lbl.config(text="measuring…")
        a.say("Calibrating camera scale…")

        def work():
            m = a.model
            head0 = np.array(a.head, float)
            f = a._w_frames(2)
            short = min(a.cam_size)
            d0 = K.nearest_dot(K.find_dots(f[0], 15, short * 0.5), m.p0)
            if d0 is None:
                raise LookupError("No dot in the camera picture. Put a printed black dot (3-10 mm) where the "
                                  "camera can see it and try again.")
            lo, hi = d0.d * 0.7, d0.d * 1.4
            # rough look: two small moves tell which way the picture moves, then bring the dot to the centre
            rough_h, rough_p = [head0], [d0.xy]
            for o in ((1.5, 0), (0, 1.5)):
                h = a._w_goto(*(head0 + o))
                dot = self._find_again(lo, hi, d0.xy, short * 0.45, "during the first small moves")
                rough_h.append(h)
                rough_p.append(dot.xy)
            Mr, _ = K.fit_scale(rough_h, rough_p)
            head0 = a._w_goto(*(head0 + Mr @ (d0.xy - m.p0)))      # dot now under the crosshair
            dot = self._find_again(lo, hi, m.p0, short * 0.3, "while centring it")
            s = 3.0
            offs = [(0, 0), (s, 0), (-s, 0), (0, s), (0, -s), (s, s), (-s, -s), (s, -s), (-s, s), (0, 0)]
            heads, pix = [], []
            centre_px = dot.xy
            Minv = np.linalg.inv(Mr)
            for o in offs:
                h = a._w_goto(*(head0 + o))
                expect = centre_px - Minv @ (h - head0)       # the dot stays put; the picture moves
                dot = self._find_again(lo, hi, expect, max(0.25 * short, 2.0 * np.linalg.norm(Minv, 2)),
                                       f"at test position {len(heads) + 1} of {len(offs)}", n=2)
                heads.append(h)
                pix.append(dot.xy)
            a._w_goto(*head0)
            M, res = K.fit_scale(heads, pix)
            rep = float(np.hypot(*(pix[0] - pix[-1])))
            return M, res, rep, d0.d

        def done(r):
            M, res, rep, dpx = r
            d = K.describe_M(M)
            if not (0.005 < d["mm_per_px"] < 0.5) or not (0.9 < d["aspect"] < 1.1):
                messagebox.showerror("Calibration", f"That result doesn't look right ({d['mm_per_px']:.4f} mm/px, "
                                     f"aspect {d['aspect']:.3f}). Was the dot moving or partly hidden?",
                                     parent=self.win)
                self.scale_lbl.config(text="failed")
                return
            old = a.model.M if a.s.get("cam_scale_ok") else None
            changed = old is None or np.abs(M - old).max() > 0.03 * d["mm_per_px"] * 2
            a.model.M = M
            a.model.p0 = np.array(a.cam_size, float) / 2
            a.s["cam_scale_ok"] = True
            if changed and old is not None and (a.s.get("cam_offset_ok") or a.s.get("cam_ref")):
                # a different (or moved) camera: the old offset and reference dot no longer apply
                a.s["cam_offset_ok"] = False
                a.s["cam_ref"] = None
                a.model.C = np.array(a.s.get("cam_offset_guess", a.model.C), float)
                messagebox.showinfo("Calibration", "The camera's scale or angle changed noticeably, so the old "
                                    "offset (Step 3) and reference dot no longer apply.\n\nType the camera's rough "
                                    "position from the laser in Step 3 and do the burns again.", parent=self.win)
            a.s["cam_health"] = {}            # relearn what's normal for the new setup
            a.s["cam_model"] = a.model.to_dict()
            save_settings(a.s)
            a._show_cal_status()
            a._refresh_buttons()
            self.refresh()
            a.say(f"Camera scale saved. Fit {res * 1000:.0f} µm, back-to-start {rep * d['mm_per_px'] * 1000:.0f} µm, "
                  f"dot {dpx * d['mm_per_px']:.2f} mm.")

        a.worker.submit(work, done, self._fail)

    # ------------------------------------------------------------------ step 1: orientation
    def _draw_arrow(self, turn):
        """turn: None (nothing yet), 0 (lined up), >0 clockwise degrees, <0 counter-clockwise degrees."""
        c = self.arrow
        c.delete("all")
        c.create_oval(10, 10, 64, 64, outline="#adb5bd", width=2)
        if turn is None:
            c.create_text(37, 37, text="?", font=("Segoe UI", 20, "bold"), fill="#adb5bd")
            return
        if abs(turn) < 3:
            c.create_text(37, 37, text="✓", font=("Segoe UI", 26, "bold"), fill="#2f9e44")
            return
        col = "#d9480f"
        extent = -min(300, 60 + abs(turn) * 2) if turn > 0 else min(300, 60 + abs(turn) * 2)
        c.create_arc(14, 14, 60, 60, start=90, extent=extent, style="arc", outline=col, width=4)
        end = math.radians(90 + extent)
        ex, ey = 37 + 23 * math.cos(end), 37 - 23 * math.sin(end)
        # arrow head, pointing along the direction of travel
        tang = end - math.pi / 2 if turn > 0 else end + math.pi / 2
        tx, ty = math.cos(tang), -math.sin(tang)
        nx, ny = -ty, tx
        c.create_polygon(ex + 9 * tx, ey + 9 * ty, ex - 6 * nx, ey - 6 * ny, ex + 6 * nx, ey + 6 * ny, fill=col)
        c.create_text(37, 37, text=f"{abs(turn):.0f}°", font=("Segoe UI", 11, "bold"), fill=col)

    def run_orient(self):
        if not self.ready():
            return
        a = self.app
        if not a._confirm_motion(10):
            return
        a.stop_evt.clear()
        self.orient_lbl.config(text="measuring…")

        def work():
            head0 = np.array(a.head, float)
            short = min(a.cam_size)
            d0 = K.nearest_dot(K.find_dots(a._w_frames(2)[0], 15, short * 0.5), a.model.p0)
            if d0 is None:
                raise LookupError("No dot in the camera picture. Put a printed black dot where the camera can see it.")
            lo, hi = d0.d * 0.7, d0.d * 1.4
            hs, ps = [head0], [d0.xy]
            for o in ((1.5, 0), (0, 1.5)):
                hs.append(a._w_goto(*(head0 + o)))
                ps.append(self._find_again(lo, hi, d0.xy, short * 0.45, "while measuring the angle").xy)
            a._w_goto(*head0)
            Mr, _ = K.fit_scale(hs, ps)
            return K.describe_M(Mr)

        def done(d):
            theta = d["angle"]
            k = round(theta / 90.0)
            r = theta - 90 * k                      # how far past the nearest square position
            target = int((90 * k) % 360)
            turn = -r if not d["mirrored"] else r    # + = turn clockwise (seen from above)
            self._draw_arrow(turn)
            if abs(r) < 3:
                txt = f"Lined up: {theta:+.1f}° (within {abs(r):.1f}° of {target}°)."
                col = "#2b8a3e"
            else:
                way = "clockwise" if turn > 0 else "counter-clockwise"
                txt = (f"Camera is at {theta:+.1f}°. Turn it about {abs(r):.0f}° {way} (seen from above) to "
                       f"line up at {target}°, then Measure again. If the number grows, turn the other way.")
                col = "#c92a2a"
            self.orient_lbl.config(text=txt, foreground=col)
            a.say(txt + "  (Redo Step 2 and Step 3 after turning the camera.)")
        a.worker.submit(work, done, self._fail)

    def _find_again(self, lo, hi, near, max_dist, where, n=1, tries=3):
        """Worker: measure the test dot near the expected spot; try a few fresh pictures before giving up,
        and keep a picture of what the camera saw if it really can't be found."""
        a = self.app
        last = None
        for _ in range(tries):
            frames = a._w_frames(n)
            dot, _ = K.measure_dot(frames, lo, hi, near, max_dist=max_dist)
            if dot is not None:
                return dot
            last = frames[0]
        path = None
        try:
            dbg = os.path.join(os.path.dirname(SETTINGS_FILE), "debug")
            os.makedirs(dbg, exist_ok=True)
            img = last.copy()
            for d in K.find_dots(last, 10, min(a.cam_size) * 0.5):
                cv2.circle(img, (int(d.x), int(d.y)), int(d.d / 2), (0, 255, 0), 2)
            cv2.circle(img, (int(near[0]), int(near[1])), int(max_dist), (0, 0, 255), 2)
            path = os.path.join(dbg, time.strftime("lost_dot_%Y%m%d_%H%M%S.png"))
            cv2.imwrite(path, img)
        except Exception:
            pass
        raise LookupError(f"Lost the dot {where}." + (f"\nA picture of what the camera saw was saved to:\n{path}"
                                                      if path else ""))

    def _fail(self, e):
        self.app.say(str(e))
        if isinstance(e, Stopped):
            return
        if isinstance(e, LookupError):
            messagebox.showwarning("Calibration", str(e), parent=self.win)
        else:
            self.app._laser_error(e)
        self.refresh()

    # ------------------------------------------------------------------ step 2
    def restart(self):
        self.burns, self.origin, self.click_for = [], None, None
        self.saved = False
        self.refresh()

    def current_C(self):
        r = self.results()
        if r is not None:
            return r[0]
        try:                     # no burns yet: start from the rough position typed in
            g = [float(self.est_x.get()), float(self.est_y.get())]
        except ValueError:
            return np.array(self.app.model.C, float)
        self.app.s["cam_offset_guess"] = g
        return np.array(g, float)

    def go_spot(self):
        if not self.ready(need_scale=True):
            return
        a = self.app
        if not a._confirm_motion(60):
            return
        if self.origin is None:
            self.origin = np.array(a.head, float)
        B = self.origin + SPOTS[len(self.burns)]
        C = self.current_C()
        a.stop_evt.clear()

        def work():
            a._w_goto(*(B - C))                       # camera over the spot: picture BEFORE the burn
            before = K.median_frame(a._w_frames(3))
            a._w_goto(*B)                             # beam over the spot
            return before

        def done(before):
            self.burns.append({"B": B, "before": before, "C": None, "Cuse": C})
            self.refresh()
            a.say(f"Spot {len(self.burns)}: press PULSE on the laser's panel now, then Find burn.")
        a.say("Moving to the spot…")
        a.worker.submit(work, done, self._fail)

    def find_burn(self):
        if not self.ready(need_scale=True) or not self.burns:
            return
        a = self.app
        b = self.burns[-1]
        C = b["Cuse"]
        m = a.model
        a.stop_evt.clear()

        def work():
            head = a._w_goto(*(b["B"] - C))           # same head position as the BEFORE picture
            after = K.median_frame(a._w_frames(3))
            exp = m.p0 + np.linalg.solve(m.M, b["B"] - head - C)    # where the burn should show
            reach = (25.0 if len([x for x in self.burns if x.get("C") is not None]) == 0 else 4.0) / m.mm_per_px
            r = K.find_burn(b["before"], after, 0.08 / m.mm_per_px, 3.0 / m.mm_per_px, near=exp, max_dist=reach)
            return head, after, r

        def done(res):
            head, after, r = res
            b["after"], b["head"] = after, head
            if r is None:
                b["auto_failed"] = True
                b["Cauto"] = None
                a.say("No burn found automatically - centre it by hand, then Accept.")
                self._centre_for_check(b, C)
                return
            self._set_burn(b, np.array(r[:2]))
        a.worker.submit(work, done, self._fail)

    def _set_burn(self, b, p):
        m = self.app.model
        off = m.M @ (p - m.p0)
        b["Cauto"] = b["B"] - b["head"] - off
        b.pop("before", None)
        self.click_for = None
        dist = float(np.hypot(*off))
        if dist < 0.5:
            # already (nearly) under the crosshair: don't move the head - your eye decides from here.
            # (A re-centre from the automatic reading could shift it a hair, e.g. when air-assist smoke
            # stains one side of the burn.)
            self.app.zoom_var.set(True)
            self.app.step_var.set("0.05")
            b["confirm"] = True
            self.app.say(f"Burn found {dist:.2f} mm from the crosshair. Check it, adjust if needed, then Accept.")
            self.refresh()
            self.win.focus_set()
            return
        self.app.say(f"Burn found {dist:.2f} mm from the crosshair - centring it for you to check.")
        self._centre_for_check(b, b["Cauto"])

    def wants_click(self, p):
        """Camera picture clicked: use it to mark the burn if we're waiting for that."""
        b = self.click_for
        if b is None:
            return False
        m = self.app.model
        r = K.find_burn(b["before"], b["after"], 0.05 / m.mm_per_px, 3.0 / m.mm_per_px,
                        near=p, max_dist=1.0 / m.mm_per_px, z_min=4) if "before" in b else None
        self._set_burn(b, np.array(r[:2]) if r else p)
        if r is None:
            self.app.say("Used the clicked point (less exact than a detected burn).")
        return True

    def save_offset(self):
        r = self.results()
        if r is None:
            return
        mean, spread, n = r
        a = self.app
        if spread > 0.1 and not messagebox.askyesno(
                "Calibration", f"The burns disagree by up to {spread:.3f} mm. Save anyway?", parent=self.win):
            return
        a.model.C = mean
        a.s["cam_offset_ok"] = True
        a.s["cam_offset_note"] = f"(±{spread:.3f}, {n} burns)"
        self.saved = True
        a.s["cam_model"] = a.model.to_dict()
        save_settings(a.s)
        a._show_cal_status()
        a._refresh_buttons()
        a.say("Camera offset saved.")
        self.refresh()


def main():
    if sys.platform == "win32":
        try:
            import ctypes
            ctypes.windll.shcore.SetProcessDpiAwareness(1)     # crisp text on high-DPI screens
        except Exception:
            pass
    simulate = "--simulate" in sys.argv
    if simulate:
        # practice mode keeps its own settings, so practising never touches the real calibration
        global SETTINGS_FILE
        base, ext = os.path.splitext(SETTINGS_FILE)
        SETTINGS_FILE = base + "_practice" + ext
    root = tk.Tk()
    App(root, simulate=simulate)
    root.mainloop()


if __name__ == "__main__":
    main()
