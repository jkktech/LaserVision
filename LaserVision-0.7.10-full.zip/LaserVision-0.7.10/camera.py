"""
camera.py - head camera for LaserVision: capture thread, dot finder, calibration maths,
and a simulated camera for trying everything with no hardware.

Coordinates
  * Frames are rotated (setting "cam_rotate") before anything else, so "pixel" always means
    a pixel of the picture you see on screen.
  * The camera model is:   machine point = head + C + M @ (p - p0)
        head  laser head position (mm, where the beam would fire)
        C     camera offset: the machine point under the image centre p0, relative to the head
        M     2x2 matrix, mm per pixel (includes the camera's rotation / mirroring)
  * M is measured by jogging the head over a fixed dot (scale calibration).
    C is measured from pulse burns (offset calibration).
"""

import math
import sys
import threading
import time

import cv2
import numpy as np

IS_WIN = sys.platform == "win32"
ROTATIONS = {0: None, 90: cv2.ROTATE_90_CLOCKWISE, 180: cv2.ROTATE_180, 270: cv2.ROTATE_90_COUNTERCLOCKWISE}


# ====================================================================== capture
class Camera:
    """Grabs frames on a background thread; always keeps the newest one with its timestamp."""

    def __init__(self, index=0, size=(1920, 1080), fmt="mjpg", rotate=270):
        self.index, self.size, self.fmt, self.rotate = index, size, fmt, rotate
        self.cap = None
        self.lock = threading.Lock()
        self.frame, self.stamp, self.count = None, 0.0, 0
        self.fps = 0.0
        self.error = None
        self._stop = threading.Event()
        self._thread = None

    def open(self):
        backend = cv2.CAP_DSHOW if IS_WIN else cv2.CAP_V4L2
        cap = cv2.VideoCapture(self.index, backend)
        if not cap.isOpened():
            raise RuntimeError(f"Camera {self.index} could not be opened (in use by another program, "
                               "or a different camera number).")
        cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc(*("MJPG" if self.fmt == "mjpg" else "YUY2" if IS_WIN else "YUYV")))
        cap.set(cv2.CAP_PROP_FRAME_WIDTH, self.size[0])
        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, self.size[1])
        cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
        ok, f = cap.read()
        if not ok:
            cap.release()
            raise RuntimeError("The camera opened but sent no picture.")
        self.cap = cap
        self._stop.clear()
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()
        return f.shape[1], f.shape[0]

    def settings_dialog(self):
        if self.cap is not None and IS_WIN:
            self.cap.set(cv2.CAP_PROP_SETTINGS, 1)

    def _run(self):
        n, t0 = 0, time.time()
        while not self._stop.is_set():
            ok, f = self.cap.read()
            t = time.time()
            if not ok:
                self.error = "Camera stopped sending pictures (unplugged?)."
                time.sleep(0.2)
                continue
            if ROTATIONS.get(self.rotate) is not None:
                f = cv2.rotate(f, ROTATIONS[self.rotate])
            with self.lock:
                self.frame, self.stamp, self.count = f, t, self.count + 1
            n += 1
            if t - t0 >= 1.0:
                self.fps, n, t0 = n / (t - t0), 0, t

    def latest(self):
        with self.lock:
            return self.frame, self.stamp, self.count

    def frames_after(self, t, n=1, timeout=5.0):
        """n frames whose exposure started after time t (so none were taken while moving)."""
        out, last, t_end = [], -1, time.time() + timeout
        # a frame's timestamp is when it arrived; it was exposed up to ~1 frame earlier
        frame_time = 1.0 / max(self.fps, 2.0)
        while len(out) < n and time.time() < t_end:
            f, stamp, cnt = self.latest()
            if f is not None and cnt != last and stamp - frame_time * 1.5 > t:
                out.append(f)
                last = cnt
            time.sleep(0.01)
        if len(out) < n:
            raise RuntimeError("No fresh picture from the camera.")
        return out

    def still_frames(self, n, t_after, ref_small=None, timeout=6.0):
        """n pictures after time t_after, once the picture has stopped changing (and, with ref_small,
        differs from the picture taken before the move - so a late, buffered picture isn't used).
        Returns (frames, note)."""
        out, prev, last, t_end = [], None, -1, time.time() + timeout
        changed = ref_small is None
        newest = None
        while time.time() < t_end:
            f, stamp, cnt = self.latest()
            if f is None or cnt == last or stamp < t_after:
                time.sleep(0.01)
                continue
            last, newest = cnt, f
            s = small_gray(f)
            if not changed and picture_change(s, ref_small) > CHANGED:
                changed = True
            still = prev is not None and picture_change(s, prev) < STILL
            prev = s
            if changed and still:
                out.append(f)
                if len(out) >= n:
                    return out, None
            else:
                out = []
        note = ("Camera picture didn't settle (vibration, or the picture is slow to update) - "
                "measured anyway." if changed else
                "Camera picture didn't change after the move - check the camera is live.")
        return (out or [newest]) if newest is not None else self.frames_after(t_after, n), note

    def close(self):
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=1.0)
        if self.cap is not None:
            self.cap.release()
        self.cap = None


STILL, CHANGED = 6.0, 14.0     # picture_change thresholds (grey levels)


def small_gray(img):
    g = to_gray(img)
    return cv2.GaussianBlur(cv2.resize(g, (g.shape[1] // 8, g.shape[0] // 8), interpolation=cv2.INTER_AREA),
                            (3, 3), 0).astype(np.int16)


def picture_change(a, b):
    """How much two small pictures differ: the strongest 0.3 % of pixel changes (so a moving dot on
    blank card still counts, but camera noise doesn't)."""
    if a.shape != b.shape:
        return 255.0
    return float(np.percentile(np.abs(a - b), 99.7))


# ====================================================================== dot finding
class Dot:
    __slots__ = ("x", "y", "d", "circ", "contrast", "fit_dx")

    def __init__(self, x, y, d, circ, contrast, fit_dx):
        self.x, self.y, self.d, self.circ, self.contrast, self.fit_dx = x, y, d, circ, contrast, fit_dx

    @property
    def xy(self):
        return np.array([self.x, self.y])

    def __repr__(self):
        return f"Dot({self.x:.2f}, {self.y:.2f}, d={self.d:.1f}px, circ={self.circ:.2f}, c={self.contrast:.0f})"


def to_gray(img):
    """Brightness as the brightest colour channel: black ink stays dark, but coloured shadows and
    brown/kraft material count as light, so a shadow beside a mark can't be mistaken for ink."""
    return img if img.ndim == 2 else img.max(axis=2)


def find_dots(img, d_min, d_max, min_circ=0.72, min_contrast=25):
    """All dark, round blobs with diameter between d_min and d_max pixels.
    Works on uneven light: each blob is compared with the material right around it."""
    g = to_gray(img)
    scale = max(1, int(round(d_max / 70)))      # find on a smaller image, refine at full size
    gs = cv2.resize(g, None, fx=1 / scale, fy=1 / scale, interpolation=cv2.INTER_AREA) if scale > 1 else g
    gs = cv2.GaussianBlur(gs, (0, 0), 1.5)
    k = int(d_max / scale * 1.4) | 1
    ker = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (k, k))
    hat = cv2.morphologyEx(gs, cv2.MORPH_BLACKHAT, ker)          # dark things smaller than k
    thr = max(min_contrast * 0.6, cv2.threshold(hat, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)[0])
    mask = (hat > thr).astype(np.uint8)
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5)))
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    H, W = g.shape
    out = []
    for c in contours:
        a = cv2.contourArea(c)
        if a < 3:
            continue
        d = 2 * math.sqrt(a / math.pi) * scale
        if not d_min <= d <= d_max:
            continue
        per = cv2.arcLength(c, True)
        circ = min(1.0, 4 * math.pi * a / per ** 2) if per > 0 else 0
        if d > 12 and circ < min_circ:
            continue
        x, y, w, h = cv2.boundingRect(c)
        if x <= 1 or y <= 1 or (x + w) * scale >= W - 2 or (y + h) * scale >= H - 2:
            continue                                               # cut off by the picture edge
        m = cv2.moments(c)
        dot = refine(g, m["m10"] / m["m00"] * scale, m["m01"] / m["m00"] * scale, d / 2)
        if dot is not None and dot.contrast >= min_contrast:
            out.append(dot)
    return out


def refine(g, cx, cy, r):
    """Sub-pixel centre of a dark dot near (cx, cy) with radius ~r.
    Inside the dot counts fully (speckle / glare inside it is ignored), the soft edge counts by
    how dark each pixel is, and the material outside counts nothing (a light halo can't pull it)."""
    H, W = g.shape
    R = int(r * 1.6 + 6)
    x0, y0 = int(cx) - R, int(cy) - R
    if x0 < 0 or y0 < 0 or x0 + 2 * R + 1 > W or y0 + 2 * R + 1 > H:
        return None
    roi = g[y0:y0 + 2 * R + 1, x0:x0 + 2 * R + 1].astype(np.float32)
    sm = cv2.GaussianBlur(roi, (0, 0), max(0.8, r / 40))
    yy, xx = np.mgrid[0:2 * R + 1, 0:2 * R + 1].astype(np.float32)
    for _ in range(2):                                 # second pass uses the improved centre
        rr = np.hypot(xx - (cx - x0), yy - (cy - y0))
        inside = rr < r * 0.6
        ring = (rr > r * 1.25) & (rr < r * 1.55)
        if inside.sum() < 3 or ring.sum() < 8:
            return None
        fg = float(np.median(sm[inside]))
        bg = float(np.percentile(sm[ring], 70))
        if bg - fg < 5:
            return None
        span = bg - fg
        lo, hi = fg + 0.2 * span, fg + 0.5 * span     # edge ramp: kept low so shadows don't count
        blob = (sm < fg + 0.35 * span).astype(np.uint8)
        n, lab = cv2.connectedComponents(blob)
        if n < 2:
            return None
        cl = lab[int(round(cy - y0)), int(round(cx - x0))]
        if cl == 0:
            near = lab[(rr < r * 0.7)]
            near = near[near > 0]
            if not len(near):
                return None
            cl = np.bincount(near).argmax()
        core = (lab == cl).astype(np.uint8)
        core = fill_holes(core)
        inner = cv2.erode(core, np.ones((3, 3), np.uint8), iterations=2).astype(bool)
        band = cv2.dilate(core, np.ones((3, 3), np.uint8), iterations=3).astype(bool) & ~inner
        w = np.zeros_like(sm)
        w[inner] = 1.0
        w[band] = np.clip((hi - sm[band]) / (hi - lo), 0, 1)
        s = w.sum()
        if s <= 0:
            return None
        nx, ny = (w * xx).sum() / s + x0, (w * yy).sum() / s + y0
        cx, cy = nx, ny
        r = math.sqrt(s / math.pi)
    # independent check: ellipse through the edge of the dot
    cs, _ = cv2.findContours(core, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    c = max(cs, key=cv2.contourArea)
    fit_dx = 0.0
    circ = 0.0
    if len(c) >= 6:
        (ex, ey), _, _ = cv2.fitEllipse(c)
        fit_dx = math.hypot(ex + x0 - cx, ey + y0 - cy)
        per = cv2.arcLength(c, True)
        circ = min(1.0, 4 * math.pi * cv2.contourArea(c) / per ** 2) if per else 0
    return Dot(cx, cy, 2 * r, circ, bg - fg, fit_dx)


def fill_holes(m):
    h, w = m.shape
    ff = np.zeros((h + 2, w + 2), np.uint8)
    inv = (1 - m).astype(np.uint8)
    cv2.floodFill(inv, ff, (0, 0), 0)
    return m | inv


def nearest_dot(dots, target_px, max_dist=None):
    if not dots:
        return None
    best = min(dots, key=lambda d: math.hypot(d.x - target_px[0], d.y - target_px[1]))
    if max_dist is not None and math.hypot(best.x - target_px[0], best.y - target_px[1]) > max_dist:
        return None
    return best


def measure_dot(frames, d_min, d_max, target_px, max_dist=None, **kw):
    """Average the dot centre over several frames. Returns (Dot, spread_px) or (None, None)."""
    found = []
    for f in frames:
        d = nearest_dot(find_dots(f, d_min, d_max, **kw), target_px, max_dist)
        if d is not None:
            found.append(d)
    if len(found) < max(1, (len(frames) + 1) // 2):
        return None, None
    xs = np.array([[d.x, d.y] for d in found])
    med = np.median(xs, axis=0)
    spread = float(np.max(np.hypot(*(xs - med).T))) if len(found) > 1 else 0.0
    best = found[0]
    return Dot(med[0], med[1], float(np.median([d.d for d in found])), best.circ,
               best.contrast, max(d.fit_dx for d in found)), spread


# ====================================================================== calibration maths
class CamModel:
    """machine = head + C + M @ (p - p0)"""

    def __init__(self, M=None, C=(0.0, 43.2), p0=(540.0, 960.0)):
        self.M = np.array(M if M is not None else [[0.0543, 0.0], [0.0, 0.0543]], float)
        self.C = np.array(C, float)
        self.p0 = np.array(p0, float)

    @property
    def mm_per_px(self):
        return float(math.sqrt(abs(np.linalg.det(self.M))))

    def to_machine(self, head, p):
        return np.asarray(head, float) + self.C + self.M @ (np.asarray(p, float) - self.p0)

    def to_pixel(self, head, pt):
        return self.p0 + np.linalg.solve(self.M, np.asarray(pt, float) - np.asarray(head, float) - self.C)

    def head_to_view(self, pt):
        """Head position that puts machine point pt under the image centre."""
        return np.asarray(pt, float) - self.C

    def to_dict(self):
        return {"M": self.M.tolist(), "C": self.C.tolist(), "p0": self.p0.tolist()}

    @classmethod
    def from_dict(cls, d):
        return cls(d["M"], d["C"], d["p0"])


def fit_scale(heads, pixels):
    """Head moved over a FIXED dot: dot pixel p_i, head h_i.  h_i + M (p_i - p0) = const
    -> M (p_i - p_j) = -(h_i - h_j).  Least squares for M (2x2) using all positions vs the mean.
    Returns M, worst residual (mm)."""
    H = np.asarray(heads, float)
    P = np.asarray(pixels, float)
    dH = H - H.mean(0)
    dP = P - P.mean(0)
    # solve dP @ M.T = -dH
    Mt, *_ = np.linalg.lstsq(dP, -dH, rcond=None)
    M = Mt.T
    res = np.hypot(*(dP @ M.T + dH).T)
    return M, float(res.max())


def describe_M(M):
    """Pixel size, camera rotation and whether the picture is mirrored."""
    det = np.linalg.det(M)
    sx = math.hypot(M[0, 0], M[1, 0])
    sy = math.hypot(M[0, 1], M[1, 1])
    ang = math.degrees(math.atan2(M[1, 0], M[0, 0]))
    return {"mm_per_px": math.sqrt(abs(det)), "sx": sx, "sy": sy, "angle": ang, "mirrored": det < 0,
            "aspect": sx / sy if sy else 0}


# ====================================================================== simulation
class SimulatedCamera:
    """Renders what the head camera would see on the simulated laser: a kraft-coloured sheet,
    black reg dots, pulse burns, sensor noise and a nozzle in one corner."""

    def __init__(self, laser, size=(1080, 1920), model=None, rotate=270):
        self.laser = laser
        self.h, self.w = size[1], size[0]       # rotated (portrait) picture
        # the TRUE camera, unknown to the app until it calibrates
        th = math.radians(-1.3)
        s = 0.0546
        self.true = CamModel([[s * math.cos(th), -s * math.sin(th)], [s * math.sin(th), s * math.cos(th)]],
                             C=(-1.84, 44.71), p0=(self.w / 2, self.h / 2))
        self.dots = []        # (x, y, diameter mm)  in machine mm
        self.burns = []
        self.fps = 8.0
        self.rotate = rotate
        self.error = None
        self.rng = np.random.default_rng(1)
        self._t0 = time.time()

    def open(self):
        return self.w, self.h

    def settings_dialog(self):
        pass

    def close(self):
        pass

    def pulse(self):
        x, y = self.laser.position_um()
        self.burns.append((x / 1000, y / 1000, 0.35))

    def render(self):
        hx, hy = (v / 1000 for v in self.laser.position_um())
        ss = 2                                         # supersample for clean edges
        img = np.full((self.h // ss, self.w // ss), 150, np.float32)
        Minv = np.linalg.inv(self.true.M)
        for (x, y, dmm), level in [(d, 25) for d in self.dots]:
            p = self.true.p0 + Minv @ (np.array([x, y]) - [hx, hy] - self.true.C)
            r = dmm / 2 / self.true.mm_per_px
            if -r < p[0] < self.w + r and -r < p[1] < self.h + r:
                # draw at 16x sub-pixel precision
                cv2.circle(img, (int(round(((p[0] + 0.5) / ss - 0.5) * 16)), int(round(((p[1] + 0.5) / ss - 0.5) * 16))),
                           max(1, int(round(r / ss * 16))), level, -1, cv2.LINE_AA, shift=4)
        img = cv2.resize(img, (self.w, self.h), interpolation=cv2.INTER_LINEAR)
        for x, y, dmm in self.burns:                   # burns: soft dark spots, exact sub-pixel position
            p = self.true.p0 + Minv @ (np.array([x, y]) - [hx, hy] - self.true.C)
            r = dmm / 2 / self.true.mm_per_px
            ix, iy = int(p[0]), int(p[1])
            R = int(r * 3 + 4)
            if R <= ix < self.w - R and R <= iy < self.h - R:
                yy, xx = np.mgrid[iy - R:iy + R + 1, ix - R:ix + R + 1]
                spot = np.exp(-((xx - p[0]) ** 2 + (yy - p[1]) ** 2) / (2 * (r / 1.2) ** 2))
                img[iy - R:iy + R + 1, ix - R:ix + R + 1] *= (1 - 0.7 * spot).astype(np.float32)
        img = cv2.GaussianBlur(img, (0, 0), 1.2)
        img += self.rng.normal(0, 7, img.shape).astype(np.float32)
        # nozzle covering the top of the picture (after rotation), like the real snapshots
        cv2.ellipse(img, (self.w // 2 + 60, -120), (420, 520), 0, 0, 180, 45, -1)
        img = np.clip(img, 0, 255).astype(np.uint8)
        col = cv2.merge([img * 0.62, img * 0.80, img * 1.0]).clip(0, 255).astype(np.uint8)
        return col

    def latest(self):
        n = int((time.time() - self._t0) * self.fps)
        if getattr(self, "_cache", (None, -1))[1] != n:
            self._cache = (self.render(), n)
        return self._cache[0], time.time(), n

    def still_frames(self, n, t_after, ref_small=None, timeout=6.0):
        return self.frames_after(t_after, n), None

    def frames_after(self, t, n=1, timeout=5.0):
        wait = t + 1.0 / self.fps - time.time()
        if wait > 0:
            time.sleep(wait)
        return [self.render() for _ in range(n)]


def find_burn(before, after, d_min, d_max, near=None, max_dist=None, min_diff=None, z_min=8.0):
    """A pulse burn: the spot that got darker between two pictures taken from the same head position.
    Returns (x, y, diameter_px, score) or None.
    Built for small, faint burns: slow light/exposure changes are removed, then the difference picture
    is searched at a few blob sizes, and the strongest spot (scored against the picture's own noise:
    camera noise, JPEG blocks, card texture) wins. With `near`, only that circle is searched."""
    gb = to_gray(before).astype(np.float32)
    ga = to_gray(after).astype(np.float32)
    ga *= float(np.median(gb)) / max(1.0, float(np.median(ga)))       # exposure drift
    diff = gb - ga
    diff -= cv2.GaussianBlur(diff, (0, 0), 15)                         # uneven light changes
    H, W = diff.shape
    # ignore very dark (ink) and very bright (glare) parts: a gain change shows up there, a burn doesn't
    bad = ((gb < 70) | (gb > 235)).astype(np.uint8)
    bad = cv2.dilate(bad, np.ones((11, 11), np.uint8)).astype(bool)
    diff[bad] = 0
    if near is not None and max_dist is not None:
        yy, xx = np.ogrid[0:H, 0:W]
        region = (xx - near[0]) ** 2 + (yy - near[1]) ** 2 <= max_dist ** 2
    else:
        region = np.ones((H, W), bool)
    region[:8, :] = region[-8:, :] = False
    region[:, :8] = region[:, -8:] = False
    best = None
    for sig in sorted({max(0.8, d_min / 2.5), 1.5, 3.0, max(1.5, min(d_max / 2.5, 8.0))}):
        resp = cv2.GaussianBlur(diff, (0, 0), sig)
        vals = resp[region]
        mad = float(np.median(np.abs(vals - np.median(vals)))) * 1.4826 + 1e-3
        z = np.where(region, resp, -1e9) / mad
        k = int(np.argmax(z))
        zy, zx = divmod(k, W)
        if best is None or z[zy, zx] > best[0]:
            best = (float(z[zy, zx]), zx, zy, sig)
    if best is None or best[0] < z_min:
        return None
    score, px, py, sig = best
    # centre: darkening-weighted centroid around the peak (twice, re-centred)
    sm = cv2.GaussianBlur(diff, (0, 0), 0.8)
    cx, cy = float(px), float(py)
    R = int(max(4, 3 * sig))
    for _ in range(2):
        x0, y0 = int(round(cx)) - R, int(round(cy)) - R
        x0, y0 = max(0, min(x0, W - 2 * R - 1)), max(0, min(y0, H - 2 * R - 1))
        patch = sm[y0:y0 + 2 * R + 1, x0:x0 + 2 * R + 1]
        w = np.clip(patch - 0.25 * patch.max(), 0, None)
        if w.sum() <= 0:
            break
        gy, gx = np.mgrid[0:w.shape[0], 0:w.shape[1]]
        cx, cy = x0 + float((w * gx).sum() / w.sum()), y0 + float((w * gy).sum() / w.sum())
    d = 2 * math.sqrt(max(1.0, float((patch > 0.5 * patch.max()).sum())) / math.pi)
    return cx, cy, d, score


def median_frame(frames):
    return frames[0] if len(frames) == 1 else np.median(np.stack(frames), axis=0).astype(np.uint8)
