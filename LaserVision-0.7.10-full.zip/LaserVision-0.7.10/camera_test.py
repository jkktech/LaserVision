"""
camera_test.py - Check a USB camera before mounting it on the laser head.
Works on Windows and Linux.

Shows a live view with a centre crosshair, the real resolution and frame rate,
and a sharpness score to help you find the best mounting height / lens focus.

Usage:
    python3 camera_test.py --list                 find which camera number is yours
    python3 camera_test.py --cam 0                open camera 0 (default size 1920x1080)
    python3 camera_test.py --cam 0 --size 2592x1944 --format yuyv
                                                  ask for a size and an uncompressed format

    --format mjpg   compressed, faster at big sizes (default)
    --format yuyv   uncompressed, cleaner image, fewer frames per second

Keys in the video window:
    c   camera settings (Windows: driver dialog; Linux: prints the controls - see below)
    s   save a snapshot (PNG, lossless) to this folder
    z   zoom 4x into the centre (to judge focus on a printed dot)
    q   quit

Linux camera settings (exposure, white balance, focus):
    v4l2-ctl -d /dev/video0 --list-ctrls-menus     list what the camera can change
    guvcview  or  qv4l2                            point-and-click settings window
"""

import argparse
import glob
import shutil
import subprocess
import sys
import time

import cv2

IS_WIN = sys.platform == "win32"
BACKEND = cv2.CAP_DSHOW if IS_WIN else cv2.CAP_V4L2


def open_camera(index, width, height, fmt):
    cap = cv2.VideoCapture(index, BACKEND)
    if not cap.isOpened():
        return None
    fourcc = "MJPG" if fmt == "mjpg" else "YUYV"
    cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc(*fourcc))
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, width)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, height)
    return cap


def list_cameras(max_index=10):
    if not IS_WIN:
        devs = sorted(glob.glob("/dev/video*"))
        print("Video devices:", ", ".join(devs) or "none found")
        if shutil.which("v4l2-ctl"):
            print(subprocess.run(["v4l2-ctl", "--list-devices"], capture_output=True, text=True).stdout)
        print("Note: one USB camera often shows up as TWO /dev/video entries; the first one is the picture.")
    print("Probing with OpenCV...")
    for i in range(max_index):
        cap = cv2.VideoCapture(i, BACKEND)
        if cap.isOpened():
            ok, frame = cap.read()
            if ok:
                h, w = frame.shape[:2]
                print(f"  camera {i}: working, default {w}x{h}")
            cap.release()
    if not IS_WIN and shutil.which("v4l2-ctl"):
        print("\nSizes/formats a camera supports:  v4l2-ctl -d /dev/video0 --list-formats-ext")


def show_settings(cap, index):
    if IS_WIN:
        cap.set(cv2.CAP_PROP_SETTINGS, 1)
        return
    dev = f"/dev/video{index}"
    if shutil.which("v4l2-ctl"):
        print(subprocess.run(["v4l2-ctl", "-d", dev, "--list-ctrls-menus"], capture_output=True, text=True).stdout)
        print("Change one with e.g.:  v4l2-ctl -d", dev, "-c auto_exposure=1   (1 = manual on most cameras)")
        print("Or open a settings window:  guvcview  /  qv4l2")
    else:
        print("Install v4l-utils to see/change camera controls:  sudo apt install v4l-utils")


def sharpness(gray):
    # Variance of the Laplacian: higher = sharper. Compare readings at different heights.
    return cv2.Laplacian(gray, cv2.CV_64F).var()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--list", action="store_true")
    ap.add_argument("--cam", type=int, default=0)
    ap.add_argument("--size", default="1920x1080", help="WIDTHxHEIGHT, e.g. 2592x1944")
    ap.add_argument("--format", choices=["mjpg", "yuyv"], default="mjpg")
    args = ap.parse_args()

    if args.list:
        list_cameras()
        return

    w, h = (int(v) for v in args.size.lower().split("x"))
    cap = open_camera(args.cam, w, h, args.format)
    if cap is None:
        hint = ("check Windows camera privacy settings" if IS_WIN else
                "check the number with --list, and that you can read /dev/video* "
                "(sudo usermod -aG video $USER, then log out/in)")
        print(f"Could not open camera {args.cam}: {hint}.")
        return

    win = "camera test  (c=settings  s=snapshot  z=zoom  q=quit)"
    cv2.namedWindow(win, cv2.WINDOW_NORMAL)
    frames, t0, fps, zoom = 0, time.time(), 0.0, False
    printed = False

    while True:
        ok, frame = cap.read()
        if not ok:
            print("Frame grab failed - camera unplugged, or that size/format isn't supported.")
            break
        fh, fw = frame.shape[:2]
        if not printed:
            print(f"Camera gives {fw}x{fh} ({args.format.upper()}); asked for {w}x{h}.")
            printed = True

        frames += 1
        if time.time() - t0 >= 1.0:
            fps = frames / (time.time() - t0)
            frames, t0 = 0, time.time()

        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        cy, cx = fh // 2, fw // 2
        score = sharpness(gray[cy - fh // 8:cy + fh // 8, cx - fw // 8:cx + fw // 8])  # centre area

        view = frame
        if zoom:
            q = 8
            view = cv2.resize(frame[cy - fh // q:cy + fh // q, cx - fw // q:cx + fw // q], (fw, fh),
                              interpolation=cv2.INTER_NEAREST)
        view = view.copy()
        vh, vw = view.shape[:2]
        cv2.line(view, (vw // 2 - 40, vh // 2), (vw // 2 + 40, vh // 2), (0, 0, 255), 1)
        cv2.line(view, (vw // 2, vh // 2 - 40), (vw // 2, vh // 2 + 40), (0, 0, 255), 1)
        text = f"{fw}x{fh} {args.format.upper()}  {fps:4.1f} fps  sharpness {score:7.1f}" + ("  ZOOM 4x" if zoom else "")
        cv2.putText(view, text, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)
        cv2.imshow(win, view)

        key = cv2.waitKey(1) & 0xFF
        if key == ord("q"):
            break
        if key == ord("c"):
            show_settings(cap, args.cam)
        if key == ord("z"):
            zoom = not zoom
        if key == ord("s"):
            name = time.strftime("snap_%Y%m%d_%H%M%S.png")
            cv2.imwrite(name, frame)
            print(f"saved {name}")

    cap.release()
    cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
