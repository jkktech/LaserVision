@echo off
cd /d "%~dp0"
py laservision.py --simulate %*
if errorlevel 1 pause
