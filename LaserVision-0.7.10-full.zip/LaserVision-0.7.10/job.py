"""
job.py - The cut job: read the customer's cut PDF, find registration marks,
handle rotate/flip, fit the correction from measured marks, write a LightBurn file.

Coordinates
  design  : mm, from the PDF page's top-left corner, X right, Y down
  oriented: design after the on-screen rotate/flip, re-zeroed so the sheet's
            top-left (back-left on the bed) is 0,0
  machine : mm on the laser bed, X right, Y toward the FRONT, origin back-left
"""

import itertools
import math
import os
import xml.etree.ElementTree as ET

import numpy as np

PT_TO_MM = 25.4 / 72.0
FLATTEN_TOL_MM = 0.005          # max deviation when turning curves into short lines

# ------------------------------------------------------------------ PDF reading


def _flatten_cubic(p0, p1, p2, p3, tol, out, depth=0):
    """Append points of a cubic Bezier (excluding p0) to out, adaptively."""
    # flatness: distance of control points from the chord
    ux = 3 * p1[0] - 2 * p0[0] - p3[0]
    uy = 3 * p1[1] - 2 * p0[1] - p3[1]
    vx = 3 * p2[0] - p0[0] - 2 * p3[0]
    vy = 3 * p2[1] - p0[1] - 2 * p3[1]
    flat = max(ux * ux, vx * vx) + max(uy * uy, vy * vy)
    if flat <= 16 * tol * tol or depth > 16:
        out.append(p3)
        return
    m01 = ((p0[0] + p1[0]) / 2, (p0[1] + p1[1]) / 2)
    m12 = ((p1[0] + p2[0]) / 2, (p1[1] + p2[1]) / 2)
    m23 = ((p2[0] + p3[0]) / 2, (p2[1] + p3[1]) / 2)
    a = ((m01[0] + m12[0]) / 2, (m01[1] + m12[1]) / 2)
    b = ((m12[0] + m23[0]) / 2, (m12[1] + m23[1]) / 2)
    mid = ((a[0] + b[0]) / 2, (a[1] + b[1]) / 2)
    _flatten_cubic(p0, m01, a, mid, tol, out, depth + 1)
    _flatten_cubic(mid, b, m23, p3, tol, out, depth + 1)


def _drawing_to_polylines(d):
    """Turn one PyMuPDF drawing into a list of polylines (lists of (x, y) in mm)."""
    polys, cur = [], None

    def P(pt):
        return (pt.x * PT_TO_MM, pt.y * PT_TO_MM)

    def start(pt):
        nonlocal cur
        if cur is None or math.dist(cur[-1], pt) > 1e-6:
            if cur and len(cur) > 1:
                polys.append(cur)
            cur = [pt]

    for it in d["items"]:
        kind = it[0]
        if kind == "l":
            a, b = P(it[1]), P(it[2])
            start(a)
            cur.append(b)
        elif kind == "c":
            a, c1, c2, b = P(it[1]), P(it[2]), P(it[3]), P(it[4])
            start(a)
            _flatten_cubic(a, c1, c2, b, FLATTEN_TOL_MM, cur)
        elif kind == "re":
            r = it[1]
            pts = [(r.x0, r.y0), (r.x1, r.y0), (r.x1, r.y1), (r.x0, r.y1), (r.x0, r.y0)]
            if cur and len(cur) > 1:
                polys.append(cur)
            polys.append([(x * PT_TO_MM, y * PT_TO_MM) for x, y in pts])
            cur = None
        elif kind == "qu":
            q = it[1]
            pts = [q.ul, q.ur, q.lr, q.ll, q.ul]
            if cur and len(cur) > 1:
                polys.append(cur)
            polys.append([P(p) for p in pts])
            cur = None
    if cur and len(cur) > 1:
        polys.append(cur)
    if d.get("closePath"):
        for p in polys:
            if math.dist(p[0], p[-1]) > 1e-6:
                p.append(p[0])
    return polys


class Mark:
    def __init__(self, x, y, size):
        self.x, self.y, self.size = x, y, size      # design mm, centre and diameter


class Job:
    def __init__(self, pdf_path):
        import pymupdf
        self.path = pdf_path
        self.name = os.path.splitext(os.path.basename(pdf_path))[0]
        doc = pymupdf.open(pdf_path)
        if len(doc) < 1:
            raise ValueError("The PDF has no pages.")
        page = doc[0]
        self.page_w = page.rect.width * PT_TO_MM
        self.page_h = page.rect.height * PT_TO_MM

        drawings = page.get_drawings()
        marks, cut, small_stroked, colors = [], [], [], {}
        for d in drawings:
            r = d["rect"]
            w, h = r.width * PT_TO_MM, r.height * PT_TO_MM
            filled = d["type"] in ("f", "fs")
            stroked = d["type"] in ("s", "fs")
            dot_like = 1.0 <= w <= 20.0 and abs(w - h) <= 0.05 * max(w, h)
            cx, cy = (r.x0 + r.x1) / 2 * PT_TO_MM, (r.y0 + r.y1) / 2 * PT_TO_MM
            if filled and dot_like:
                marks.append(Mark(cx, cy, w))
            elif stroked:
                polys = _drawing_to_polylines(d)
                col = d.get("color") or (0, 0, 0)
                hexcol = "#%02x%02x%02x" % tuple(int(round(max(0, min(1, c)) * 255)) for c in col[:3])
                for poly in polys:
                    cut.append(poly)
                    colors[id(poly)] = hexcol
                if dot_like:
                    small_stroked.append((Mark(cx, cy, w), polys))
        # Fallback: some files use outlined circles as marks instead of filled dots.
        if len(marks) < 3 and len(small_stroked) >= 3:
            marks = [m for m, _ in small_stroked]
            drop = {id(p) for _, polys in small_stroked for p in polys}
            cut = [p for p in cut if id(p) not in drop]
        self.marks = marks
        self.cut = [np.array(p, dtype=float) for p in cut]
        self.cut_colors = [colors.get(id(p), "#000000") for p in cut]   # original stroke colour per path
        self.notes = []
        if len(self.marks) < 3:
            self.notes.append(f"Found only {len(self.marks)} registration mark(s); at least 3 are needed.")
        if len(self.marks) == 3:
            self.notes.append("3 marks: the correction is exact, with no spare mark to cross-check a misread.")
        for m in self.marks:
            r = m.size / 2
            if m.x - r < 0.5 or m.y - r < 0.5 or m.x + r > self.page_w - 0.5 or m.y + r > self.page_h - 0.5:
                self.notes.append(f"A mark at ({m.x:.1f}, {m.y:.1f}) mm touches the page edge; make sure it prints completely.")
        # cut lines closer together than the laser can cut separately: doubled lines / traced strokes
        self.close_lines = find_close_lines(self.cut, CLOSE_LINE_MM)
        if self.close_lines:
            n = len(self.close_lines)
            self.notes.append(
                f"{n} place{'s' if n != 1 else ''} where cut lines run less than {CLOSE_LINE_MM:g} mm apart "
                "(red circles on the bed view): probably doubled lines or a traced/outlined stroke. "
                "They would be cut twice - check the cut file with the customer.")
            for c in self.close_lines[:6]:
                self.notes.append(f"   at X {c['x']:.1f}  Y {c['y']:.1f} mm on the sheet: {c['length']:.0f} mm of line, "
                                  f"about {c['gap']:.2f} mm apart" + ("  (one path doubling back)" if c["same"] else ""))
            if n > 6:
                self.notes.append(f"   …and {n - 6} more")

    @property
    def mark_xy(self):
        return np.array([(m.x, m.y) for m in self.marks], dtype=float)


# ------------------------------------------------------------------ doubled-line check

CLOSE_LINE_MM = 0.5         # cut lines closer than this get flagged (kerf is ~0.15 mm)
MIN_CLOSE_RUN_MM = 1.5      # ...when they stay that close for at least this long (not just touching)


def _resample(poly, step):
    """Points every `step` mm along a polyline, with their distance along it."""
    p = np.asarray(poly, float)
    seg = np.hypot(*np.diff(p, axis=0).T)
    s = np.concatenate([[0.0], np.cumsum(seg)])
    L = s[-1]
    if L <= 0:
        return p[:1], np.zeros(1), 0.0
    t = np.arange(0.0, L, step)
    return np.column_stack([np.interp(t, s, p[:, 0]), np.interp(t, s, p[:, 1])]), t, L


def find_close_lines(polys, gap=CLOSE_LINE_MM, min_run=MIN_CLOSE_RUN_MM):
    """Places where cut lines run within `gap` of each other: a second copy of a line, a stroke traced
    into an outline, or one path doubling back on itself. Returns one dict per place
    (x, y, length, gap, same) - lines that merely cross or touch at a point are ignored."""
    step = gap / 2
    pts, pid, arc, plen, closed = [], [], [], [], []
    for i, poly in enumerate(polys):
        q, t, L = _resample(poly, step)
        pts.append(q)
        pid.append(np.full(len(q), i))
        arc.append(t)
        poly = np.asarray(poly, float)
        is_closed = len(poly) > 2 and np.hypot(*(poly[0] - poly[-1])) < 0.01
        plen.append(np.full(len(q), L))
        closed.append(np.full(len(q), is_closed))
    if not pts:
        return []
    P = np.vstack(pts)
    pid, arc, plen, closed = (np.concatenate(v) for v in (pid, arc, plen, closed))
    N = len(P)
    # grid join: candidate pairs from neighbouring cells
    cell = np.floor(P / gap).astype(np.int64)
    cell -= cell.min(0)
    W = int(cell[:, 1].max()) + 3
    key = cell[:, 0] * W + cell[:, 1]
    order = np.argsort(key, kind="stable")
    sk = key[order]
    I, J = [], []
    for dx in (-1, 0, 1):
        for dy in (-1, 0, 1):
            nk = key + dx * W + dy
            lo = np.searchsorted(sk, nk, "left")
            hi = np.searchsorted(sk, nk, "right")
            cnt = hi - lo
            if cnt.sum() == 0:
                continue
            ii = np.repeat(np.arange(N), cnt)
            offs = np.arange(cnt.sum()) - np.repeat(np.cumsum(cnt) - cnt, cnt)
            jj = order[np.repeat(lo, cnt) + offs]
            keep = ii < jj
            I.append(ii[keep])
            J.append(jj[keep])
    I, J = np.concatenate(I), np.concatenate(J)
    d = np.hypot(*(P[I] - P[J]).T)
    near = d < gap
    I, J, d = I[near], J[near], d[near]
    same = pid[I] == pid[J]
    da = np.abs(arc[I] - arc[J])
    da = np.where(same & closed[I], np.minimum(da, plen[I] - da), da)
    # same path: only points far apart ALONG the line count (not neighbours, not a tight corner)
    real = ~same | (da > max(4 * gap, 2.0))
    I, J, d, same = I[real], J[real], d[real], same[real]
    if not len(I):
        return []
    # group into places: connected runs of flagged points (union-find over flagged pairs + line order)
    flagged = np.unique(np.concatenate([I, J]))
    parent = {int(k): int(k) for k in flagged}

    def find(a):
        while parent[a] != a:
            parent[a] = parent[parent[a]]
            a = parent[a]
        return a

    def union(a, b):
        ra, rb = find(a), find(b)
        if ra != rb:
            parent[ra] = rb
    for a, b in zip(I.tolist(), J.tolist()):
        union(a, b)
    fs = set(parent)
    for k in flagged.tolist():                      # neighbours along the same line
        if k + 1 in fs and pid[k + 1] == pid[k]:
            union(k, k + 1)
    groups = {}
    for k in flagged.tolist():
        groups.setdefault(find(k), []).append(k)
    nearest = {}                                    # each flagged point's distance to the other line
    for a, b, dd in zip(I.tolist(), J.tolist(), d.tolist()):
        for k in (a, b):
            if dd < nearest.get(k, 1e9):
                nearest[k] = dd
    gap_of = {}
    for a, sm in zip(I.tolist(), same.tolist()):
        r = find(a)
        gap_of[r] = gap_of.get(r, True) and sm
    out = []
    for r, members in groups.items():
        members = np.array(members)
        # length of line involved: points on the longest-involved path x step
        counts = np.bincount(pid[members])
        length = counts.max() * step
        if length < min_run:
            continue
        c = P[members].mean(0)
        k = members[np.argmin(np.hypot(*(P[members] - c).T))]
        typical = float(np.median([nearest[int(m)] for m in members]))
        out.append({"x": float(P[k, 0]), "y": float(P[k, 1]), "length": float(length),
                    "gap": typical, "same": bool(gap_of[r])})
    out.sort(key=lambda o: -o["length"])
    return out


# ------------------------------------------------------------------ orientation

ROT_CW = np.array([[0, -1], [1, 0]])     # 90 deg clockwise on screen (Y down)
FLIP_H = np.array([[-1, 0], [0, 1]])     # mirror left/right
FLIP_V = np.array([[1, 0], [0, -1]])     # mirror front/back


class Orientation:
    """One of the 8 ways the sheet can lie: an integer 2x2 matrix."""

    def __init__(self, m=None):
        self.m = np.eye(2, dtype=int) if m is None else np.array(m, dtype=int)

    def rotated_cw(self):
        return Orientation(ROT_CW @ self.m)

    def rotated_ccw(self):
        return Orientation(ROT_CW.T @ self.m)

    def flipped_h(self):
        return Orientation(FLIP_H @ self.m)

    def flipped_v(self):
        return Orientation(FLIP_V @ self.m)

    @property
    def mirrored(self):
        return round(np.linalg.det(self.m)) < 0

    def describe(self):
        if np.array_equal(self.m, FLIP_V):
            return "Flipped front/back"
        base = FLIP_H if self.mirrored else np.eye(2, dtype=int)
        r = np.eye(2, dtype=int)
        for k in range(4):
            if np.array_equal(r @ base, self.m):
                rot = ["", "rotated 90° clockwise", "rotated 180°", "rotated 90° counter-clockwise"][k]
                break
            r = ROT_CW @ r
        if self.mirrored:
            return "Flipped left/right" + (f", then {rot}" if rot else "")
        return rot.capitalize() if rot else "As designed"

    def frame(self, job):
        """Return (A, w, h): oriented = A @ [x, y, 1]; w, h = oriented sheet size."""
        corners = np.array([[0, 0], [job.page_w, 0], [job.page_w, job.page_h], [0, job.page_h]])
        rc = corners @ self.m.T
        lo = rc.min(axis=0)
        A = np.hstack([self.m.astype(float), -lo.reshape(2, 1)])
        size = rc.max(axis=0) - lo
        return A, size[0], size[1]


def apply(A, pts):
    pts = np.asarray(pts, dtype=float)
    return pts @ A[:, :2].T + A[:, 2]


def compose(A2, A1):
    """Affine A2 after A1."""
    M = A2[:, :2] @ A1[:, :2]
    t = A2[:, :2] @ A1[:, 2] + A2[:, 2]
    return np.hstack([M, t.reshape(2, 1)])


# ------------------------------------------------------------------ fitting

def fit_translation(src, dst):
    t = np.mean(np.asarray(dst) - np.asarray(src), axis=0)
    return np.array([[1, 0, t[0]], [0, 1, t[1]]], dtype=float)


def fit_similarity(src, dst):
    """Rotation + uniform scale + translation (no mirroring), least squares."""
    src, dst = np.asarray(src, float), np.asarray(dst, float)
    cs, cd = src.mean(0), dst.mean(0)
    s, d = src - cs, dst - cd
    a = np.sum(s[:, 0] * d[:, 0] + s[:, 1] * d[:, 1])
    b = np.sum(s[:, 0] * d[:, 1] - s[:, 1] * d[:, 0])
    n = np.sum(s ** 2)
    a, b = a / n, b / n
    M = np.array([[a, -b], [b, a]])
    t = cd - M @ cs
    return np.hstack([M, t.reshape(2, 1)])


def fit_rigid(src, dst):
    """Rotation + translation only (no scale, no mirroring)."""
    A = fit_similarity(src, dst)
    M = A[:, :2]
    k = math.hypot(M[0, 0], M[1, 0])
    if k > 0:
        M = M / k
    src, dst = np.asarray(src, float), np.asarray(dst, float)
    t = dst.mean(0) - M @ src.mean(0)
    return np.hstack([M, t.reshape(2, 1)])


def fit_affine(src, dst):
    src, dst = np.asarray(src, float), np.asarray(dst, float)
    X = np.hstack([src, np.ones((len(src), 1))])
    sol, *_ = np.linalg.lstsq(X, dst, rcond=None)
    return sol.T


def best_fit(src, dst):
    n = len(src)
    if n == 0:
        return None
    if n == 1:
        return fit_translation(src, dst)
    if n == 2:
        return fit_similarity(src, dst)
    return fit_affine(src, dst)


def describe_fit(A, src=None, dst=None):
    """Plain-numbers summary of an affine fit plus warnings."""
    M = A[:, :2]
    c1, c2 = M[:, 0], M[:, 1]
    sx, sy = np.linalg.norm(c1), np.linalg.norm(c2)
    rot = math.degrees(math.atan2(c1[1], c1[0]))
    det = np.linalg.det(M)
    cosang = float(np.dot(c1, c2) / (sx * sy)) if sx and sy else 0.0
    skew = 90.0 - math.degrees(math.acos(max(-1.0, min(1.0, abs(cosang)))))
    info = {"scale_x": sx, "scale_y": sy, "rotation_deg": rot, "skew_deg": skew,
            "mirrored": det < 0, "residuals": [], "max_residual": 0.0}
    if src is not None and dst is not None and len(src):
        res = np.linalg.norm(apply(A, src) - np.asarray(dst), axis=1)
        info["residuals"] = res.tolist()
        info["max_residual"] = float(res.max())
    warn = []
    if det < 0:
        warn.append("The measured marks are MIRRORED compared to the design - the flip setting is wrong.")
    if abs(sx - 1) > 0.01 or abs(sy - 1) > 0.01:
        warn.append(f"Scale is off by more than 1% (X {100*(sx-1):+.2f}%, Y {100*(sy-1):+.2f}%). "
                    "Wrong mark measured, or wrong orientation?")
    if abs(skew) > 0.5:
        warn.append(f"Skew of {skew:.2f} deg - a mark was probably measured wrongly.")
    if info["max_residual"] > 0.15:
        warn.append(f"Marks disagree by up to {info['max_residual']:.3f} mm - re-measure.")
    info["warnings"] = warn
    return info


# ------------------------------------------------------------------ checks

def orientation_margin(points):
    """How different the mark layout looks from its own rotations/mirror images.
    Returns the smallest RMS mismatch (mm) over all relabelings that could be
    confused. Big = safe; under a few mm = the app can't tell orientations apart."""
    P = np.asarray(points, float)
    n = len(P)
    if n < 3 or n > 7:
        return None
    best = float("inf")
    for mirror in (False, True):
        Q = P * np.array([-1, 1]) if mirror else P
        for perm in itertools.permutations(range(n)):
            if not mirror and perm == tuple(range(n)):
                continue
            src = Q[list(perm)]
            A = fit_rigid(src, P)
            rms = float(np.sqrt(np.mean(np.sum((apply(A, src) - P) ** 2, axis=1))))
            best = min(best, rms)
    return best


def first_mark_index(oriented_marks, sheet_h):
    """The mark nearest the sheet's front-left corner (front = larger Y)."""
    pts = np.asarray(oriented_marks)
    d = np.hypot(pts[:, 0], sheet_h - pts[:, 1])
    return int(np.argmin(d))


def measure_order(oriented_marks, sheet_h):
    """Front-left mark first, then nearest-next to keep travel short."""
    pts = np.asarray(oriented_marks)
    order = [first_mark_index(pts, sheet_h)]
    left = set(range(len(pts))) - set(order)
    while left:
        last = pts[order[-1]]
        nxt = min(left, key=lambda i: np.hypot(*(pts[i] - last)))
        order.append(nxt)
        left.remove(nxt)
    return order


# ------------------------------------------------------------------ LightBurn output

def _cutsetting(index, name, output=True):
    """A layer with no speed/power: you apply your own preset in LightBurn."""
    cs = ET.Element("CutSetting", type="Cut")
    for tag, val in (("index", index), ("name", name), ("doOutput", 1 if output else 0), ("priority", index)):
        ET.SubElement(cs, tag, Value=str(val))
    return cs


def _shape(points, cut_index):
    """Closed or open polyline as a LightBurn path."""
    pts = list(points)
    closed = len(pts) > 2 and math.dist(pts[0], pts[-1]) < 1e-4
    if closed:
        pts = pts[:-1]
    n = len(pts)
    verts = "".join(f"V{x:.4f} {y:.4f}c0x1c1x1" for x, y in pts)
    segs = n if closed else n - 1
    prims = "".join(f"L{i} {(i + 1) % n}" for i in range(segs))
    sh = ET.Element("Shape", Type="Path", CutIndex=str(cut_index))
    ET.SubElement(sh, "XForm").text = "1 0 0 1 0 0"
    ET.SubElement(sh, "VertList").text = verts
    ET.SubElement(sh, "PrimList").text = prims
    return sh


def circle_points(cx, cy, r, n=48):
    return [(cx + r * math.cos(2 * math.pi * k / n), cy + r * math.sin(2 * math.pi * k / n))
            for k in range(n)] + [(cx + r, cy)]


def read_layers(path):
    """List the layers (with their full settings) saved in one of your LightBurn files."""
    root = ET.parse(path).getroot()
    layers = []
    for cs in root:
        if not cs.tag.startswith("CutSetting"):
            continue
        def val(tag, default=""):
            el = cs.find(tag)
            return el.get("Value", default) if el is not None else default
        try:
            idx = int(val("index", "-1"))
        except ValueError:
            continue
        mode = {"Cut": "Line", "Scan": "Fill", "Image": "Image"}.get(cs.get("type", ""), cs.get("type", ""))
        layers.append({"index": idx, "name": val("name", f"C{idx:02d}"), "mode": mode,
                       "speed": val("speed"), "power": val("maxPower"),
                       "output": val("doOutput", "1") != "0", "element": cs})
    layers.sort(key=lambda d: d["index"])
    return layers


def layer_label(layer):
    sp = f"  {float(layer['speed']):g}/{float(layer['power']):g}" if layer["speed"] and layer["power"] else ""
    off = "  - OUTPUT OFF" if not layer.get("output", True) else ""
    return f"{layer['index']:02d}  {layer['name']}  ({layer['mode']}{sp}){off}"


def write_lbrn2(out_path, cut_polys_machine, marks_machine, mark_size, bed_h, flip_y=False,
                cut_indices=None, preset_file=None, include_marks=True, tool_names=None):
    """cut_polys_machine / marks_machine are in machine mm (Y toward front).
    cut_indices: LightBurn layer number for each cut path (default all on layer 0).
    preset_file: one of your own .lbrn2 files; its layers (speed, power, passes, ...)
    are copied in unchanged so your presets are used exactly as saved.

    Verified against LightBurn 2.2 on a Thunder Nova 51 (origin back-left): LightBurn
    saves MirrorY="True" for this machine and stores coordinates exactly as shown in
    its X/Y boxes, which equal the laser's own coordinates. So with MirrorY="True" the
    machine coordinates go in unchanged. (With MirrorY="False" LightBurn re-mirrors the
    design when opening it, which shifted everything in our first test.)"""
    def conv(p):
        p = np.asarray(p, float)
        return np.column_stack([p[:, 0], bed_h - p[:, 1]]) if flip_y else p

    if cut_indices is None:
        cut_indices = [0] * len(cut_polys_machine)
    attrs = dict(AppVersion="2.2.00", FormatVersion="1", MaterialHeight="0")
    used = set()
    if preset_file:
        tpl = ET.parse(preset_file).getroot()
        for k in ("AppVersion", "DeviceName", "FormatVersion", "MaterialHeight"):
            if tpl.get(k):
                attrs[k] = tpl.get(k)
    attrs.update(MirrorX="False", MirrorY="True")
    root = ET.Element("LightBurnProject", **attrs)
    ET.SubElement(root, "Thumbnail", Source="")
    if preset_file:
        for el in tpl:
            if el.tag in ("VariableText", "UIPrefs") or el.tag.startswith("CutSetting"):
                root.append(el)
                if el.tag.startswith("CutSetting") and el.find("index") is not None:
                    used.add(int(el.find("index").get("Value")))
    for idx in sorted(set(cut_indices) - used):
        if idx >= 30:            # tool layer (T1, T2): shown in LightBurn, never sent to the laser
            tl = ET.Element("CutSetting", type="Tool")
            name = (tool_names or {}).get(idx, f"T{idx - 29}")
            for tag, val in (("index", idx), ("name", name), ("priority", 99)):
                ET.SubElement(tl, tag, Value=str(val))
            root.append(tl)
        else:
            root.append(_cutsetting(idx, f"C{idx:02d}"))
        used.add(idx)
    # Registration marks always go on tool layer T1 (index 30): LightBurn shows them but
    # never sends them to the laser, so they are a reference only and can't be cut.
    mark_idx = 30
    if include_marks and mark_idx not in used:
        t1 = ET.Element("CutSetting", type="Tool")
        for tag, val in (("index", 30), ("name", "T1"), ("priority", 99)):
            ET.SubElement(t1, tag, Value=str(val))
        root.append(t1)
    for poly, idx in zip(cut_polys_machine, cut_indices):
        root.append(_shape(conv(poly), idx))
    if include_marks:
        for (mx, my) in marks_machine:
            r = mark_size / 2
            root.append(_shape(conv(circle_points(mx, my, r)), mark_idx))
            root.append(_shape(conv([(mx - 1.6 * r, my), (mx + 1.6 * r, my)]), mark_idx))   # centre cross
            root.append(_shape(conv([(mx, my - 1.6 * r), (mx, my + 1.6 * r)]), mark_idx))
    ET.SubElement(root, "Notes", ShowOnLoad="0",
                  Notes="Generated by LaserVision. Use Start From: Absolute Coords.")
    ET.indent(root)
    ET.ElementTree(root).write(out_path, encoding="UTF-8", xml_declaration=True)
    return out_path


def write_svg(out_path, cut_polys_machine, colors, marks_machine, mark_size, bed_w, bed_h,
              include_marks=True, mark_color="#00a0ff"):
    """SVG in machine mm on a page the size of the bed (SVG Y points down = toward the
    front, same as the laser). Each cut path keeps its original colour from the PDF so
    LightBurn puts it on the same layer as before. Marks get their own colour."""
    def path_d(p):
        p = np.asarray(p, float)
        closed = len(p) > 2 and np.allclose(p[0], p[-1], atol=1e-4)
        pts = p[:-1] if closed else p
        d = "M" + " L".join(f"{x:.4f},{y:.4f}" for x, y in pts)
        return d + (" Z" if closed else "")

    out = ['<?xml version="1.0" encoding="UTF-8"?>',
           f'<svg xmlns="http://www.w3.org/2000/svg" width="{bed_w:g}mm" height="{bed_h:g}mm" '
           f'viewBox="0 0 {bed_w:g} {bed_h:g}">',
           '<g id="aligned_cut" fill="none" stroke-width="0.1">']
    for p, c in zip(cut_polys_machine, colors):
        out.append(f'<path stroke="{c}" d="{path_d(p)}"/>')
    if include_marks:
        for mx, my in marks_machine:
            out.append(f'<circle stroke="{mark_color}" cx="{mx:.4f}" cy="{my:.4f}" r="{mark_size / 2:.4f}"/>')
    out += ['</g>', '</svg>']
    with open(out_path, "w", encoding="utf-8") as f:
        f.write("\n".join(out))
    return out_path
