@echo off
cd /d "%~dp0"
py laservision.py %*
if errorlevel 1 pause
