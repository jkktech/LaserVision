LaserVision 0.7.10 - registration-mark alignment for LightBurn + Thunder/Ruida
===========================================================================

UPDATING (from 0.7.4 on)
  Keep "Start LaserVision.bat" in the main LaserVision folder and point your desktop shortcut
  at it. Unzip each new version next to the others (it arrives as its own LaserVision-x.y.z
  folder). The launcher always starts the newest one, and every version shares the
  settings.json next to the launcher - calibration, layers and IP carry over automatically.
  Old version folders can be deleted any time.

USER MANUAL
  Press "? Help" (top right) or F1 in LaserVision: opens manual\manual.html in your browser.

SETUP (once)
  1. Unzip this folder to C:\LaserVision (replacing the older test scripts is fine).
  2. Open Command Prompt and run:   py -m pip install pymupdf numpy opencv-python
  3. Double-click "LaserVision (simulated laser).bat" to try it with no laser
     (it also simulates the camera, so you can practise calibrating and auto-measuring).
     Double-click "LaserVision.bat" to use the real laser (close LightBurn first).

USING IT
  1. Open cut PDF...      Marks are found automatically (small filled dots).
  2. Sheet on bed         Rotate/flip until the picture matches the sheet on the bed.
                          The app tells you if it doesn't fit the bed.
  3. Connect              Close LightBurn first - only one program can talk to the laser.
  4. Measure marks        Mark 1 is ringed in blue (click another mark to start there).
                          Jog the red dot onto the centre of the mark (arrow keys, small
                          steps near the end), then press Record (or Enter).
                          After mark 1, "Go to mark" drives to where the next mark should be.
     Doubled cut lines: if any cut lines run less than 0.5 mm apart (a doubled line or a
                          traced/outlined stroke), the app warns you and circles them in red.
                          They'd be cut twice - check the file with the customer.
  5. Check the Result box Rotation / scale / skew should be small; red lines are warnings.
  6. Layers               "Layer presets from" = your everyday .lbrn2 file (chosen once, remembered).
                          Each colour can also be "Don't cut - leave out" or "Don't cut - show on
                          T2 (reference)". Click a colour swatch to see its lines on the bed.
                          Its layers are copied in unchanged. For each cut-line colour in the
                          customer's PDF, pick which of your layers it goes on (remembered).
  7. Save                 Saves next to the cut PDF with the same name (sticker_cut.lbrn2,
                          or sticker_cut.svg). Asks before replacing an existing file.
     Save + open          Hands the laser back to LightBurn and opens the file there.
     Save + CUT           Same, then asks you to confirm and tells LightBurn to start the job.

CAMERA (new in 0.7)
  Camera picture settings (button "Picture…", Windows driver dialog):
      Camera Control tab: UNTICK Low Light Compensation (it limits you to ~5 fps),
      untick Exposure Auto and set it by hand (start at -6). Video Proc Amp: untick
      White Balance Auto. If the picture is too dark, add light - don't raise Gain.
  Settings: camera number, size (1920x1080), rotation (270 = turned left 90°).

  CALIBRATE (button "Calibrate…") - once, and again if the camera is bumped or moved:
  Step 1  Scale     Put any printed black dot under the camera near the red crosshair,
                    press Measure scale. The head moves up to 3 mm around it.
  Step 2  Offset    Tape card / masking tape under the head, set the panel's pulse power LOW.
                    5 times: "Go to next spot" -> press PULSE on the laser's panel -> "Find burn".
                    The app compares a before/after picture to find each burn, then
                    "Save offset". The burns should agree within ~0.02 mm.
                    If a burn isn't found, click it in the camera picture.
  Check any time:   burn a pulse on scrap, click the burn in the camera picture - the
                    crosshair should land right on it.

  CAMERA HEALTH (bumped camera / sagging mount)
  After every camera-measured job the app checks the camera by itself: are the dots the size
  they usually are (camera height), and does a 3 mm test move land where the calibration says
  (camera twisted/tilted)? The Result box shows "Camera health"; a problem gives a warning.
  It learns what's normal over the first job after each calibration.
  It can't see a camera that only SLID sideways - for that, the optional reference dot:
  Calibrate… Step 3: a small black dot that never moves (machine frame, not the honeycomb).
  "Check camera" then measures it in seconds and can correct the offset without burns.
  Tick "Check the camera automatically before every Auto-measure" to do it every job.

  MEASURING WITH THE CAMERA
  Jog until mark 1 (orange on the bed view) shows in the camera picture, then press
  "Auto-measure all". It finds each mark (searching around if needed), centres on it and
  measures it. Esc or Stop halts the head. The Result box lists each mark's size and
  steadiness - a ! means check that one. Clicking the camera picture moves that spot
  under the crosshair. The red-dot method (Record red dot here) still works.

IN LIGHTBURN
  SVG:   File > Import. LightBurn may drop the import anywhere, so with the imported group
         still selected, set the 3x3 anchor to TOP-LEFT and type the XPos / YPos shown in
         LaserVision's Result box. That puts it exactly where it was measured.
  .lbrn2: File > Open (not Import).
  Then:  set "Start From" to Absolute Coords; click a reg-mark circle (anchor centre) and
         check it matches a "measured centre" in the Result box; Frame with the red dot
         before the first real cut.
  Reg marks: in .lbrn2 files they are always on tool layer T1 (circle + centre cross) -
         visible for reference, never sent to the laser. SVGs contain no reg marks.

FILES
  laservision.py   the app          job.py    PDF reading, orientation, maths, LightBurn file
  ruida.py         laser comms      camera.py  camera, mark finder, calibration maths
  settings.json is created on first run (holds your camera calibration)
