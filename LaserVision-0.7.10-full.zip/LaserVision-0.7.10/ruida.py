"""
ruida.py - Talk to a Ruida laser controller over Ethernet (UDP).

Proven on a Thunder Laser (Ruida 6445, card ID 0x6517, scramble 0x88):
  * DA 00 <addr>        reads a value (position, bed size, card ID)
  * D9 00/01 02 <num>   moves X / Y by a RELATIVE distance (laser off)

Protocol details come from community reverse engineering (EduTech Wiki "Ruida",
jnweiger/ruida-laser). Unofficial - keep moves small and checked.
"""

import socket
import threading
import time

RUIDA_PORT = 50200      # controller listens here
REPLY_PORT = 40200      # controller replies to this port on the PC (LightBurn uses it too)
DEFAULT_MAGIC = 0x88
KNOWN_MAGICS = [0x88, 0x11, 0x33, 0x77, 0x10, 0x60, 0xA1, 0x1A, 0x83,
                0x16, 0x34, 0x75, 0x99, 0x13, 0x76, 0x38]

ACK, ERR, CHECKSUM_FAIL = 0xCC, 0xCD, 0xCF


class LaserError(Exception):
    pass


# ------------------------------------------------------------ byte helpers

def swizzle_byte(b, magic):
    b ^= (b >> 7) & 0xFF
    b ^= (b << 7) & 0xFF
    b ^= (b >> 7) & 0xFF
    b ^= magic
    return (b + 1) & 0xFF


def unswizzle_byte(b, magic):
    b = (b - 1) & 0xFF
    b ^= magic
    b ^= (b >> 7) & 0xFF
    b ^= (b << 7) & 0xFF
    b ^= (b >> 7) & 0xFF
    return b


def swizzle(data, magic):
    return bytes(swizzle_byte(b, magic) for b in data)


def unswizzle(data, magic):
    return bytes(unswizzle_byte(b, magic) for b in data)


def encode_int35(value):
    value &= (1 << 35) - 1
    return bytes((value >> s) & 0x7F for s in (28, 21, 14, 7, 0))


def decode_int35(data):
    value = 0
    for b in data[:5]:
        value = (value << 7) | (b & 0x7F)
    if value & (1 << 34):
        value -= 1 << 35
    return value


# ------------------------------------------------------------------ client

class Ruida:
    """Real controller. All positions are in micrometres (um), machine coordinates:
    X grows to the right, Y grows toward the front (origin = back-left)."""

    def __init__(self, ip, magic=DEFAULT_MAGIC, timeout=2.0):
        self.ip, self.magic, self.timeout = ip, magic, timeout
        self.lock = threading.Lock()
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            self.sock.bind(("", REPLY_PORT))
        except OSError as e:
            self.sock.close()
            raise LaserError(
                f"Could not open UDP port {REPLY_PORT} ({e}). LightBurn is probably "
                "running - close it completely (check the system tray) and try again.")
        self.sock.settimeout(timeout)

    def close(self):
        try:
            self.sock.close()
        except OSError:
            pass

    # ---- low level
    def _drain(self):
        self.sock.setblocking(False)
        try:
            while True:
                self.sock.recvfrom(4096)
        except (BlockingIOError, OSError):
            pass
        finally:
            self.sock.settimeout(self.timeout)

    def _send_raw(self, payload):
        scrambled = swizzle(payload, self.magic)
        checksum = sum(scrambled) & 0xFFFF
        self.sock.sendto(checksum.to_bytes(2, "big") + scrambled, (self.ip, RUIDA_PORT))

    def _send(self, payload, retries=2):
        for attempt in range(retries + 1):
            self._drain()
            self._send_raw(payload)
            try:
                raw, _ = self.sock.recvfrom(4096)
            except socket.timeout:
                if attempt < retries:
                    continue
                raise LaserError("No reply from the laser. Check the IP address, that the PC is "
                                 "on the same network, and that Windows Firewall allows Python.")
            if len(raw) == 1:
                code = unswizzle_byte(raw[0], self.magic)
                if code == ACK:
                    return None
                if code == CHECKSUM_FAIL and attempt < retries:
                    continue
                if code == ERR:
                    raise LaserError("The laser replied ERROR to a command.")
                guess = [m for m in KNOWN_MAGICS if unswizzle_byte(raw[0], m) == ACK]
                hint = f" Try scramble key 0x{guess[0]:02X}." if guess else ""
                raise LaserError(f"Unexpected reply 0x{raw[0]:02X}.{hint}")
            return unswizzle(raw, self.magic)

    def _read_param(self, a0, a1):
        early = self._send(bytes([0xDA, 0x00, a0, a1]))
        packets = [early] if early else []
        deadline = time.time() + self.timeout
        key = bytes([0xDA, 0x01, a0, a1])
        while True:
            for pkt in packets:
                i = pkt.find(key)
                if i >= 0 and len(pkt) >= i + 9:
                    return decode_int35(pkt[i + 4:i + 9])
            if time.time() > deadline:
                raise LaserError(f"No data reply for parameter {a0:02X} {a1:02X}.")
            try:
                raw, _ = self.sock.recvfrom(4096)
                packets = [unswizzle(raw, self.magic)]
            except socket.timeout:
                packets = []

    # ---- public (thread safe)
    def card_id(self):
        with self.lock:
            return self._read_param(0x05, 0x7E) & 0xFFFF

    def bed_size_um(self):
        with self.lock:
            return self._read_param(0x00, 0x26), self._read_param(0x00, 0x36)

    def position_um(self):
        with self.lock:
            return self._read_param(0x04, 0x21), self._read_param(0x04, 0x31)

    def move_x_rel(self, dx):
        with self.lock:
            self._send(bytes([0xD9, 0x00, 0x02]) + encode_int35(int(dx)))

    def move_y_rel(self, dy):
        with self.lock:
            self._send(bytes([0xD9, 0x01, 0x02]) + encode_int35(int(dy)))

    def wait_until_stopped(self, max_wait=60.0):
        last, t0 = None, time.time()
        while time.time() - t0 < max_wait:
            time.sleep(0.15)
            pos = self.position_um()
            if pos == last:
                return pos
            last = pos
        raise LaserError("The head did not stop moving within the time limit.")

    def goto_um(self, tx, ty, settle_tol=3):
        """Absolute go-to built from relative moves, with one small correction pass."""
        x, y = self.position_um()
        if tx != x:
            self.move_x_rel(tx - x)
            x, y = self.wait_until_stopped()
        if ty != y:
            self.move_y_rel(ty - y)
            x, y = self.wait_until_stopped()
        dx, dy = tx - x, ty - y
        if settle_tol < abs(dx) <= 1000:
            self.move_x_rel(dx)
            x, y = self.wait_until_stopped()
        if settle_tol < abs(dy) <= 1000:
            self.move_y_rel(dy)
            x, y = self.wait_until_stopped()
        return x, y


class SimulatedRuida:
    """Stand-in laser for trying the app with no machine connected.
    Behaves like the real Thunder: 1300 x 900 mm bed, moves land a few um short."""

    def __init__(self, bed=(1300000, 900000), start=(650000, 450000)):
        self.bed = bed
        self.x, self.y = start
        self.lock = threading.Lock()

    def close(self):
        pass

    def card_id(self):
        return 0x6517

    def bed_size_um(self):
        return self.bed

    def position_um(self):
        return self.x, self.y

    def _short(self, d):
        return d - (2 if d > 2000 else -2 if d < -2000 else 0)

    def move_x_rel(self, dx):
        time.sleep(min(abs(dx) / 400000, 2.0))
        self.x = max(0, min(self.bed[0], self.x + self._short(int(dx))))

    def move_y_rel(self, dy):
        time.sleep(min(abs(dy) / 400000, 2.0))
        self.y = max(0, min(self.bed[1], self.y + self._short(int(dy))))

    def wait_until_stopped(self, max_wait=60.0):
        return self.x, self.y

    goto_um = Ruida.goto_um
