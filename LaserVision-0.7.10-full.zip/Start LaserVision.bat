@echo off
rem ==========================================================================
rem  Start LaserVision.bat  -  keep this file in the folder that holds the
rem  LaserVision-0.7.x version folders, and point your desktop shortcut here.
rem  It always starts the NEWEST version folder (by version number), and all
rem  versions share one settings.json (camera calibration, layers, IP) kept
rem  next to this file.
rem  Add  --simulate  to the shortcut's target to start the simulated laser.
rem ==========================================================================
setlocal
cd /d "%~dp0"
set "ROOT=%~dp0"
set "LATEST="

for /f "usebackq delims=" %%D in (`powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-ChildItem -LiteralPath '%ROOT%' -Directory | Where-Object { $_.Name -match '^LaserVision-\d+(\.\d+)+$' -and (Test-Path (Join-Path $_.FullName 'laservision.py')) } | Sort-Object { [version]($_.Name.Substring(12)) } | Select-Object -Last 1 -ExpandProperty FullName"`) do set "LATEST=%%D"

if not defined LATEST (
    echo No LaserVision-x.y.z folder found in:
    echo   %ROOT%
    echo Unzip a LaserVision version here first.
    pause
    exit /b 1
)

rem First run with a shared settings file: bring over the newest settings.json
rem from the version folders, so your calibration and layer choices carry over.
if not exist "%ROOT%settings.json" (
    for /f "usebackq delims=" %%S in (`powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-ChildItem -LiteralPath '%ROOT%' -Directory | Where-Object { $_.Name -like 'LaserVision*' } | ForEach-Object { Join-Path $_.FullName 'settings.json' } | Where-Object { Test-Path -LiteralPath $_ } | Get-Item | Sort-Object LastWriteTime | Select-Object -Last 1 -ExpandProperty FullName"`) do (
        copy /y "%%S" "%ROOT%settings.json" >nul
        echo Copied settings from %%S
    )
)

set "LASERVISION_SETTINGS=%ROOT%settings.json"
echo Starting %LATEST%
call "%LATEST%\LaserVision.bat" %*
endlocal
