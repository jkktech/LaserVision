@echo off
rem Installs (or repairs) the add-ons LaserVision needs. Run once after installing Python.
echo Installing LaserVision add-ons: pymupdf, numpy, opencv-python ...
py -m pip install --upgrade pymupdf numpy opencv-python
if errorlevel 1 (
    echo.
    echo Something went wrong. Is Python installed, and does "py --version" work in Command Prompt?
) else (
    echo.
    echo Done. You can now double-click "Start LaserVision.bat".
)
pause
