"""
lightburn_api.py - LightBurn's REST API (LightBurn 2.2 and newer) and its older UDP command port.

REST API (http://127.0.0.1:19520): pairing once (LightBurn shows a consent dialog), then every
request carries a token made from the saved secret. LaserVision asks for three permissions:
  state   - read LightBurn's status (and the "file imported" event)
  project - read the open project (file name, shape count)
  upload  - open a file in LightBurn
It never asks for permission to change settings, and the API itself can't start a job.

UDP command port (127.0.0.1:19840, replies on 19841): used when the API isn't paired or
LightBurn is older than 2.2.

Python standard library only.
"""

import hashlib
import hmac
import http.client
import json
import os
import socket
import threading
import time

HOST, PORT = "127.0.0.1", 19520
UDP_OUT, UDP_IN = 19840, 19841
APP_NAME = "LaserVision"
CAPABILITIES = ["state", "project", "upload"]


class ApiUnavailable(Exception):
    """LightBurn isn't running, is older than 2.2, or has the API switched off."""


class NotPaired(Exception):
    """No secret, or LightBurn no longer accepts it (pair again)."""


def token(secret, t=None):
    minute = int(t if t is not None else time.time()) // 60
    return hmac.new(secret.encode(), str(minute).encode(), hashlib.sha256).hexdigest()


def _request(method, path, secret=None, body=None, headers=None, timeout=5.0):
    """One HTTP request. Returns (status, parsed JSON or None)."""
    conn = http.client.HTTPConnection(HOST, PORT, timeout=timeout)
    hdrs = dict(headers or {})
    if secret:
        hdrs["Authorization"] = f"Bearer {token(secret)}"
    try:
        conn.request(method, path, body=body, headers=hdrs)
        r = conn.getresponse()
        raw = r.read()
    except (OSError, http.client.HTTPException) as e:
        raise ApiUnavailable(f"LightBurn's API didn't answer ({e}).")
    finally:
        conn.close()
    if r.status == 401:
        raise NotPaired("LightBurn didn't accept LaserVision's pairing.")
    try:
        data = json.loads(raw) if raw else None
    except ValueError:
        data = None
    return r.status, data


def pair(timeout=45.0):
    """Ask LightBurn for a secret. LightBurn shows a dialog; the user has 30 s to allow it.
    Returns the secret, or raises ApiUnavailable / NotPaired."""
    body = json.dumps({"application_name": APP_NAME, "capabilities": CAPABILITIES}).encode()
    try:
        status, data = _request("POST", "/api/connect", body=body,
                                headers={"Content-Type": "application/json"}, timeout=timeout)
    except NotPaired:
        raise NotPaired("Pairing was declined in LightBurn.")
    if status == 200 and isinstance(data, dict) and data.get("secret"):
        return data["secret"]
    raise NotPaired(f"Pairing was declined or timed out (HTTP {status}).")


def status(secret):
    """{'device_name': ..., 'connected': ...}. Note: 'connected' doesn't track a Ruida over the
    network, so LaserVision only uses device_name."""
    if not secret:
        raise NotPaired("Not paired with LightBurn.")
    st, data = _request("GET", "/api/status", secret)
    if st != 200 or not isinstance(data, dict):
        raise ApiUnavailable(f"Unexpected answer from LightBurn (HTTP {st}).")
    return data


def project(secret):
    """{'filename': ..., 'modified': ..., 'shape_count': ...} of the project open in LightBurn."""
    st, data = _request("GET", "/api/project", secret)
    if st != 200 or not isinstance(data, dict):
        raise ApiUnavailable(f"Unexpected answer from LightBurn (HTTP {st}).")
    return data


class _EventWatch:
    """Listens on LightBurn's event stream (/api/events) for one 'file_imported' event."""

    def __init__(self, secret, timeout):
        self.secret, self.timeout = secret, timeout
        self.ready = threading.Event()        # stream is open
        self.done = threading.Event()         # file_imported arrived (or the stream failed)
        self.result = None                    # {"success": bool, "error": str} or None
        self.error = None
        self.conn = None
        threading.Thread(target=self._run, daemon=True).start()

    def _run(self):
        try:
            self.conn = http.client.HTTPConnection(HOST, PORT, timeout=self.timeout)
            self.conn.request("GET", "/api/events", headers={
                "Authorization": f"Bearer {token(self.secret)}", "Accept": "text/event-stream"})
            r = self.conn.getresponse()
            if r.status == 401:
                raise NotPaired("LightBurn didn't accept LaserVision's pairing.")
            if r.status != 200:
                raise ApiUnavailable(f"LightBurn's event stream answered HTTP {r.status}.")
            self.ready.set()
            event, data = None, []
            deadline = time.time() + self.timeout
            while time.time() < deadline and not self.done.is_set():
                line = r.readline()
                if not line:
                    break
                line = line.decode("utf-8", "replace").rstrip("\r\n")
                if line == "":
                    if event == "file_imported":
                        try:
                            self.result = json.loads("\n".join(data) or "{}")
                        except ValueError:
                            self.result = {"success": False, "error": "unreadable event"}
                        break
                    event, data = None, []
                elif line.startswith(":"):
                    continue                  # ":connected" / ":keepalive" comments
                elif line.startswith("event:"):
                    event = line[6:].strip()
                elif line.startswith("data:"):
                    data.append(line[5:].strip())
        except Exception as e:                # timeout, connection closed, ...
            self.error = e
        finally:
            self.ready.set()
            self.done.set()
            self.close()

    def close(self):
        try:
            if self.conn is not None:
                self.conn.close()
        except Exception:
            pass


def open_file(secret, path, timeout=25.0):
    """Open `path` in LightBurn as the current project (like File > Open), and wait until LightBurn
    says whether the import worked. Returns a short message; raises on failure."""
    if not secret:
        raise NotPaired("Not paired with LightBurn.")
    with open(path, "rb") as f:
        payload = f.read()
    watch = _EventWatch(secret, timeout)
    watch.ready.wait(5.0)
    if watch.error is not None and isinstance(watch.error, (NotPaired, ApiUnavailable)):
        raise watch.error
    st, _ = _request("POST", "/api/file/open", secret, body=payload, timeout=15.0, headers={
        "Content-Type": "application/octet-stream", "X-Filename": os.path.basename(path)})
    if st not in (200, 202):
        watch.close()
        raise ApiUnavailable(f"LightBurn refused the file (HTTP {st}).")
    if not watch.done.wait(timeout):
        watch.close()
        raise TimeoutError("LightBurn received the file but didn't confirm it opened. "
                           "Is a dialog open in LightBurn (for example 'save changes?')?")
    res = watch.result
    if res is None:
        # the stream dropped before the event; fall back to asking what's open now
        try:
            p = project(secret)
        except Exception:
            p = {}
        if os.path.splitext(os.path.basename(str(p.get("filename", ""))))[0] == \
                os.path.splitext(os.path.basename(path))[0]:
            return f"LightBurn opened it ({p.get('shape_count', '?')} shapes)."
        raise TimeoutError("LightBurn didn't confirm that the file opened. Check LightBurn.")
    if not res.get("success"):
        raise RuntimeError(f"LightBurn couldn't open the file: {res.get('error') or 'unknown reason'}")
    try:
        p = project(secret)
        return f"LightBurn opened it ({p.get('shape_count', '?')} shapes)."
    except Exception:
        return "LightBurn opened it."


# ------------------------------------------------------------------ old UDP command port

def udp(cmd, timeout=3.0):
    """Send one command to LightBurn's UDP port. Returns the reply ('OK', '!', '?') or None."""
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        sock.bind(("127.0.0.1", UDP_IN))
        sock.settimeout(timeout)
        sock.sendto(cmd.encode(), ("127.0.0.1", UDP_OUT))
        reply, _ = sock.recvfrom(256)
        return reply.decode(errors="replace").strip()
    except OSError:
        return None
    finally:
        sock.close()
